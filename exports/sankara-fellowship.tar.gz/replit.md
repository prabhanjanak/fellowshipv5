# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Fellowship Entrance Exam Artifact

`artifacts/fellowship` — full-stack web application for Sankara Eye Foundation fellowship admissions.

### Roles & Routes
- Super Admin / Program Admin: `/dashboard`, `/programs`, `/programs/:id`, `/specialities`, `/units`, `/candidates`, `/candidates/:id`, `/exams`, `/exams/:id`, `/rankings`, `/allocations`, `/staff` (super_admin only)
- Exam Coordinator: `/coordinator`, `/candidates`
- Doctor: `/doctor`, `/candidates`
- Student: `/student`, `/student/exams`, `/student/exam/:examId` (full-screen runner), `/student/preferences`, `/student/documents`, `/student/allocation`, `/profile`

### Test credentials (seeded)
- superadmin@sankara.org / admin@123
- programadmin@sankara.org / program@123
- coord.bangalore@sankara.org / coord@123
- dr.priya@sankara.org / doctor@123
- aarav.mehta@example.com / student@123

### Conventions
- API client hooks return `{ data }` directly (no double-unwrap). Pass `{ query: { queryKey: getXxxQueryKey(...) } }` so caching works.
- JWT token stored in `localStorage` as `fellowship_token`; `lib/api-client-react/src/custom-fetch.ts` attaches `Authorization: Bearer …` and redirects to `/login` on 401.
- Toasts via `useToast` from `@/hooks/use-toast`.
- PDF allocation letters: decode base64 with `downloadPdfFromBase64` / `openPdfFromBase64` in `@/lib/status`.
- Branding: white surface + orange→amber gradient (`from-orange-500 to-amber-500`) for primary actions.
