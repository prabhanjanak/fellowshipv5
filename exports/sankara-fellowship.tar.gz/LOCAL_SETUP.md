# Running the Sankara Fellowship Platform on Your Laptop

Follow these steps to run the entire system on your local machine (Windows, macOS, or Linux).

---

## 1. Install the prerequisites

Install these once on your laptop:

| Tool | Version | Where to get it |
|------|---------|-----------------|
| **Node.js** | 24 (LTS) | https://nodejs.org/ |
| **pnpm** | latest | After installing Node, run: `npm install -g pnpm` |
| **PostgreSQL** | 14 or newer | https://www.postgresql.org/download/ |
| **Git** (optional) | latest | https://git-scm.com/ |

Verify your install in a terminal:
```bash
node --version    # should print v24.x
pnpm --version
psql --version
```

---

## 2. Get the project onto your laptop

Either clone from your Git host or unzip the downloaded `.zip` file.

```bash
# unzip path or git clone path …
cd fellowship-platform
```

---

## 3. Create the database

Open a terminal and run:

```bash
# Linux / macOS
sudo -u postgres psql -c "CREATE DATABASE sankara_fellowship;"
sudo -u postgres psql -c "CREATE USER sankara WITH PASSWORD 'sankara_dev';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE sankara_fellowship TO sankara;"

# Windows (in psql prompt as superuser)
CREATE DATABASE sankara_fellowship;
CREATE USER sankara WITH PASSWORD 'sankara_dev';
GRANT ALL PRIVILEGES ON DATABASE sankara_fellowship TO sankara;
```

---

## 4. Configure environment variables

Create a file named **`.env`** in the project root with the following contents:

```bash
DATABASE_URL=postgresql://sankara:sankara_dev@localhost:5432/sankara_fellowship
SESSION_SECRET=change-me-to-a-long-random-string
JWT_SECRET=another-long-random-string-just-for-jwt
NODE_ENV=development
PORT=8080
```

Generate a strong secret with:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

---

## 5. Install dependencies

From the project root:

```bash
pnpm install
```

This installs every workspace package (API server, web app, shared client, db).

---

## 6. Push the database schema and seed sample data

```bash
pnpm --filter @workspace/db run push
pnpm --filter @workspace/api-server run seed
```

The seed creates 5 hospital units, 2 fellowship programs, 6 specialities, 15 sample candidates, and one sample MCQ + psychometric exam.

---

## 7. Start the backend API

In one terminal:

```bash
pnpm --filter @workspace/api-server run dev
```

You should see: `Server listening on port 8080`.

---

## 8. Start the web frontend

In a **second** terminal:

```bash
pnpm --filter @workspace/fellowship run dev
```

You should see: `Local: http://localhost:5173/` (or similar).

Open that URL in your browser.

---

## 9. Login with the seeded accounts

| Role | Email | Password |
|------|-------|----------|
| Super Admin | `superadmin@sankara.org` | `admin@123` |
| Program Admin | `programadmin@sankara.org` | `program@123` |
| Exam Coordinator | `coord.bangalore@sankara.org` | `coord@123` |
| Doctor | `dr.priya@sankara.org` | `doctor@123` |
| Student | `aarav.mehta@example.com` | `student@123` |

---

## Common issues

**Port 8080 already in use?**
Change `PORT` in `.env` to e.g. `8081`.

**`pnpm: command not found`?**
Run `npm install -g pnpm` again, then close and reopen the terminal.

**Database connection error?**
- Confirm Postgres is running: `pg_isready`
- Confirm the password in `.env` matches the one you set in step 3.

**Schema out of date after a code update?**
Re-run: `pnpm --filter @workspace/db run push`.

---

## Stopping the app

Press `Ctrl + C` in each terminal window.
