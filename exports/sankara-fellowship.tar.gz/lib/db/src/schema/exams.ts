import { pgTable, serial, text, integer, boolean, timestamp, doublePrecision, jsonb } from "drizzle-orm/pg-core";
import { programsTable } from "./programs";

export const examsTable = pgTable("exams", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  kind: text("kind").notNull(),
  programId: integer("program_id").references(() => programsTable.id, { onDelete: "set null" }),
  durationMinutes: integer("duration_minutes").notNull().default(60),
  totalQuestions: integer("total_questions").notNull().default(20),
  passingScore: doublePrecision("passing_score"),
  description: text("description"),
  active: boolean("active").notNull().default(true),
  startsAt: timestamp("starts_at", { withTimezone: true }),
  endsAt: timestamp("ends_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
export type ExamRow = typeof examsTable.$inferSelect;
export type InsertExam = typeof examsTable.$inferInsert;

export const questionsTable = pgTable("questions", {
  id: serial("id").primaryKey(),
  examId: integer("exam_id").notNull().references(() => examsTable.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(),
  body: text("body").notNull(),
  marks: doublePrecision("marks").notNull().default(1),
  pairId: integer("pair_id"),
  rule: jsonb("rule"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
export type QuestionRow = typeof questionsTable.$inferSelect;
export type InsertQuestion = typeof questionsTable.$inferInsert;

export const optionsTable = pgTable("options", {
  id: serial("id").primaryKey(),
  questionId: integer("question_id").notNull().references(() => questionsTable.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  isCorrect: boolean("is_correct").notNull().default(false),
  score: doublePrecision("score"),
  position: integer("position").notNull().default(0),
});
export type OptionRow = typeof optionsTable.$inferSelect;
export type InsertOption = typeof optionsTable.$inferInsert;
