import { pgTable, serial, integer, text, timestamp, doublePrecision, uniqueIndex } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { candidatesTable } from "./candidates";

export const doctorAssignmentsTable = pgTable("doctor_assignments", {
  id: serial("id").primaryKey(),
  doctorId: integer("doctor_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  candidateId: integer("candidate_id").notNull().references(() => candidatesTable.id, { onDelete: "cascade" }),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  uniq: uniqueIndex("doctor_candidate_uniq").on(t.doctorId, t.candidateId),
}));
export type DoctorAssignmentRow = typeof doctorAssignmentsTable.$inferSelect;

export const interviewScoresTable = pgTable("interview_scores", {
  id: serial("id").primaryKey(),
  candidateId: integer("candidate_id").notNull().references(() => candidatesTable.id, { onDelete: "cascade" }),
  doctorId: integer("doctor_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  score: doublePrecision("score").notNull(),
  remarks: text("remarks"),
  submittedAt: timestamp("submitted_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  uniq: uniqueIndex("interview_candidate_doctor_uniq").on(t.candidateId, t.doctorId),
}));
export type InterviewScoreRow = typeof interviewScoresTable.$inferSelect;
