import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { usersTable, unitsTable } from "./users";
import { specialitiesTable } from "./programs";

export const candidatesTable = pgTable("candidates", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }).unique(),
  candidateCode: text("candidate_code").notNull().unique(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  dateOfBirth: text("date_of_birth"),
  gender: text("gender"),
  qualification: text("qualification"),
  collegeName: text("college_name"),
  address: text("address"),
  unitId: integer("unit_id").references(() => unitsTable.id, { onDelete: "set null" }),
  status: text("status").notNull().default("registered"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
export type CandidateRow = typeof candidatesTable.$inferSelect;
export type InsertCandidate = typeof candidatesTable.$inferInsert;

export const candidatePreferencesTable = pgTable("candidate_preferences", {
  id: serial("id").primaryKey(),
  candidateId: integer("candidate_id").notNull().references(() => candidatesTable.id, { onDelete: "cascade" }),
  specialityId: integer("speciality_id").notNull().references(() => specialitiesTable.id, { onDelete: "cascade" }),
  preferenceOrder: integer("preference_order").notNull(),
});
export type PreferenceRow = typeof candidatePreferencesTable.$inferSelect;

export const documentsTable = pgTable("documents", {
  id: serial("id").primaryKey(),
  candidateId: integer("candidate_id").notNull().references(() => candidatesTable.id, { onDelete: "cascade" }),
  docType: text("doc_type").notNull(),
  fileName: text("file_name").notNull(),
  contentBase64: text("content_base64").notNull(),
  uploadedAt: timestamp("uploaded_at", { withTimezone: true }).notNull().defaultNow(),
});
export type DocumentRow = typeof documentsTable.$inferSelect;
