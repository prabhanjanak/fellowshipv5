import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";

export const programsTable = pgTable("programs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  description: text("description"),
  academicYear: text("academic_year").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
export type ProgramRow = typeof programsTable.$inferSelect;
export type InsertProgram = typeof programsTable.$inferInsert;

export const specialitiesTable = pgTable("specialities", {
  id: serial("id").primaryKey(),
  programId: integer("program_id").notNull().references(() => programsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  code: text("code").notNull(),
  seats: integer("seats").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
export type SpecialityRow = typeof specialitiesTable.$inferSelect;
export type InsertSpeciality = typeof specialitiesTable.$inferInsert;
