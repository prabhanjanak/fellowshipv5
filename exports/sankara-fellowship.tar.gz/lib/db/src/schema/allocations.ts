import { pgTable, serial, integer, text, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { candidatesTable } from "./candidates";
import { programsTable, specialitiesTable } from "./programs";
import { unitsTable } from "./users";

export const allocationsTable = pgTable("allocations", {
  id: serial("id").primaryKey(),
  candidateId: integer("candidate_id").notNull().references(() => candidatesTable.id, { onDelete: "cascade" }).unique(),
  programId: integer("program_id").notNull().references(() => programsTable.id, { onDelete: "cascade" }),
  specialityId: integer("speciality_id").references(() => specialitiesTable.id, { onDelete: "set null" }),
  unitId: integer("unit_id").references(() => unitsTable.id, { onDelete: "set null" }),
  status: text("status").notNull(),
  rank: integer("rank"),
  totalScore: doublePrecision("total_score"),
  allocatedAt: timestamp("allocated_at", { withTimezone: true }).notNull().defaultNow(),
});
export type AllocationRow = typeof allocationsTable.$inferSelect;
export type InsertAllocation = typeof allocationsTable.$inferInsert;
