import { pgTable, serial, integer, timestamp, doublePrecision, jsonb } from "drizzle-orm/pg-core";
import { candidatesTable } from "./candidates";
import { examsTable, questionsTable, optionsTable } from "./exams";

export const examAttemptsTable = pgTable("exam_attempts", {
  id: serial("id").primaryKey(),
  candidateId: integer("candidate_id").notNull().references(() => candidatesTable.id, { onDelete: "cascade" }),
  examId: integer("exam_id").notNull().references(() => examsTable.id, { onDelete: "cascade" }),
  questionIds: jsonb("question_ids").notNull(),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  deadline: timestamp("deadline", { withTimezone: true }).notNull(),
  submittedAt: timestamp("submitted_at", { withTimezone: true }),
  score: doublePrecision("score"),
  maxScore: doublePrecision("max_score"),
});
export type AttemptRow = typeof examAttemptsTable.$inferSelect;
export type InsertAttempt = typeof examAttemptsTable.$inferInsert;

export const attemptAnswersTable = pgTable("attempt_answers", {
  id: serial("id").primaryKey(),
  attemptId: integer("attempt_id").notNull().references(() => examAttemptsTable.id, { onDelete: "cascade" }),
  questionId: integer("question_id").notNull().references(() => questionsTable.id, { onDelete: "cascade" }),
  optionId: integer("option_id").references(() => optionsTable.id, { onDelete: "set null" }),
  numericValue: doublePrecision("numeric_value"),
});
export type AttemptAnswerRow = typeof attemptAnswersTable.$inferSelect;
