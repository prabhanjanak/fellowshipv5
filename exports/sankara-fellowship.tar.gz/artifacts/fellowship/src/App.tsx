import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/lib/auth";
import NotFound from "@/pages/not-found";

import { Shell } from "@/components/layout/Shell";

import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import ProgramsPage from "@/pages/programs";
import ProgramDetailPage from "@/pages/program-detail";
import SpecialitiesPage from "@/pages/specialities";
import UnitsPage from "@/pages/units";
import CandidatesPage from "@/pages/candidates";
import CandidateDetailPage from "@/pages/candidate-detail";
import StaffPage from "@/pages/staff";
import ExamsPage from "@/pages/exams";
import ExamDetailPage from "@/pages/exam-detail";
import RankingsPage from "@/pages/rankings";
import AllocationsPage from "@/pages/allocations";
import CoordinatorPage from "@/pages/coordinator";
import DoctorPage from "@/pages/doctor";
import StudentHomePage from "@/pages/student-home";
import StudentExamsPage from "@/pages/student-exams";
import StudentExamRunnerPage from "@/pages/student-exam-runner";
import StudentPreferencesPage from "@/pages/student-preferences";
import StudentDocumentsPage from "@/pages/student-documents";
import StudentAllocationPage from "@/pages/student-allocation";
import ProfilePage from "@/pages/profile";

const queryClient = new QueryClient();

function ProtectedRoute({ component: Component, allowedRoles }: { component: React.ComponentType; allowedRoles?: string[] }) {
  const { user, isLoading } = useAuth();
  if (isLoading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!user) return <Redirect to="/login" />;
  if (allowedRoles && !allowedRoles.includes(user.role)) return <Redirect to="/" />;
  return (
    <Shell>
      <Component />
    </Shell>
  );
}

function FullScreenProtectedRoute({ component: Component, allowedRoles }: { component: React.ComponentType; allowedRoles?: string[] }) {
  const { user, isLoading } = useAuth();
  if (isLoading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!user) return <Redirect to="/login" />;
  if (allowedRoles && !allowedRoles.includes(user.role)) return <Redirect to="/" />;
  return <Component />;
}

function RootRedirect() {
  const { user, isLoading } = useAuth();
  if (isLoading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!user) return <Redirect to="/login" />;
  const role = user.role;
  if (role === "super_admin" || role === "program_admin") return <Redirect to="/dashboard" />;
  if (role === "exam_coordinator") return <Redirect to="/coordinator" />;
  if (role === "doctor") return <Redirect to="/doctor" />;
  if (role === "student") return <Redirect to="/student" />;
  return <Redirect to="/login" />;
}

const ADMINS = ["super_admin", "program_admin"];
const STAFF_VIEW = ["super_admin", "program_admin", "exam_coordinator", "doctor"];

function Router() {
  return (
    <Switch>
      <Route path="/" component={RootRedirect} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />

      <Route path="/dashboard">{() => <ProtectedRoute component={Dashboard} allowedRoles={ADMINS} />}</Route>
      <Route path="/programs">{() => <ProtectedRoute component={ProgramsPage} allowedRoles={ADMINS} />}</Route>
      <Route path="/programs/:id">{() => <ProtectedRoute component={ProgramDetailPage} allowedRoles={ADMINS} />}</Route>
      <Route path="/specialities">{() => <ProtectedRoute component={SpecialitiesPage} allowedRoles={STAFF_VIEW} />}</Route>
      <Route path="/units">{() => <ProtectedRoute component={UnitsPage} allowedRoles={ADMINS} />}</Route>
      <Route path="/candidates">{() => <ProtectedRoute component={CandidatesPage} allowedRoles={STAFF_VIEW} />}</Route>
      <Route path="/candidates/:id">{() => <ProtectedRoute component={CandidateDetailPage} allowedRoles={STAFF_VIEW} />}</Route>
      <Route path="/staff">{() => <ProtectedRoute component={StaffPage} allowedRoles={["super_admin"]} />}</Route>
      <Route path="/exams">{() => <ProtectedRoute component={ExamsPage} allowedRoles={ADMINS} />}</Route>
      <Route path="/exams/:id">{() => <ProtectedRoute component={ExamDetailPage} allowedRoles={ADMINS} />}</Route>
      <Route path="/rankings">{() => <ProtectedRoute component={RankingsPage} allowedRoles={ADMINS} />}</Route>
      <Route path="/allocations">{() => <ProtectedRoute component={AllocationsPage} allowedRoles={ADMINS} />}</Route>

      <Route path="/coordinator">{() => <ProtectedRoute component={CoordinatorPage} allowedRoles={["exam_coordinator"]} />}</Route>
      <Route path="/doctor">{() => <ProtectedRoute component={DoctorPage} allowedRoles={["doctor"]} />}</Route>

      <Route path="/student">{() => <ProtectedRoute component={StudentHomePage} allowedRoles={["student"]} />}</Route>
      <Route path="/student/exams">{() => <ProtectedRoute component={StudentExamsPage} allowedRoles={["student"]} />}</Route>
      <Route path="/student/exam/:examId">{() => <FullScreenProtectedRoute component={StudentExamRunnerPage} allowedRoles={["student"]} />}</Route>
      <Route path="/student/preferences">{() => <ProtectedRoute component={StudentPreferencesPage} allowedRoles={["student"]} />}</Route>
      <Route path="/student/documents">{() => <ProtectedRoute component={StudentDocumentsPage} allowedRoles={["student"]} />}</Route>
      <Route path="/student/allocation">{() => <ProtectedRoute component={StudentAllocationPage} allowedRoles={["student"]} />}</Route>
      <Route path="/profile">{() => <ProtectedRoute component={ProfilePage} allowedRoles={["student"]} />}</Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <Router />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
