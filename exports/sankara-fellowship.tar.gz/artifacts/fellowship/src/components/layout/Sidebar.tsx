import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  Users, 
  BookOpen, 
  MapPin, 
  FileText, 
  Award, 
  LogOut,
  GraduationCap,
  ClipboardList,
  Activity,
  ListOrdered
} from "lucide-react";

export function Sidebar() {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  if (!user) return null;

  const role = user.role;

  const links = [];

  if (role === "super_admin" || role === "program_admin") {
    links.push(
      { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
      { href: "/programs", label: "Programs", icon: BookOpen },
      { href: "/specialities", label: "Specialities", icon: Award },
      { href: "/units", label: "Units", icon: MapPin },
      { href: "/exams", label: "Exams", icon: FileText },
      { href: "/candidates", label: "Candidates", icon: Users },
      { href: "/rankings", label: "Rankings", icon: ListOrdered },
      { href: "/allocations", label: "Allocations", icon: ClipboardList }
    );
    if (role === "super_admin") {
      links.push({ href: "/staff", label: "Staff Users", icon: Users });
    }
  } else if (role === "exam_coordinator") {
    links.push(
      { href: "/coordinator", label: "Coordinator Home", icon: LayoutDashboard }
    );
  } else if (role === "doctor") {
    links.push(
      { href: "/doctor", label: "Interviews", icon: Activity }
    );
  }

  // Student navigation might be different, but if using same sidebar:
  if (role === "student") {
    links.push(
      { href: "/student", label: "My Profile", icon: Users },
      { href: "/student/exams", label: "Exams", icon: FileText },
      { href: "/student/preferences", label: "Preferences", icon: ListOrdered },
      { href: "/student/documents", label: "Documents", icon: ClipboardList },
      { href: "/student/allocation", label: "Allocation", icon: GraduationCap }
    );
  }

  return (
    <aside className="w-64 border-r bg-card flex flex-col h-[calc(100vh-4rem)]">
      <div className="flex-1 overflow-y-auto py-4">
        <nav className="space-y-1 px-2">
          {links.map((link) => {
            const Icon = link.icon;
            const isActive = location === link.href || location.startsWith(link.href + "/");
            return (
              <Link key={link.href} href={link.href}>
                <div
                  className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium cursor-pointer transition-colors ${
                    isActive
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-muted"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {link.label}
                </div>
              </Link>
            );
          })}
        </nav>
      </div>
      <div className="p-4 border-t">
        <div className="mb-4 px-2">
          <p className="text-sm font-medium truncate">{user.fullName}</p>
          <p className="text-xs text-muted-foreground truncate">{user.email}</p>
        </div>
        <Button variant="outline" className="w-full justify-start text-destructive" onClick={logout}>
          <LogOut className="h-4 w-4 mr-2" />
          Logout
        </Button>
      </div>
    </aside>
  );
}
