import { useState } from "react";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListPrograms,
  useCreateProgram,
  getListProgramsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, BookOpen, Users, GraduationCap, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ProgramsPage() {
  const { data: programs, isLoading } = useListPrograms({
    query: { queryKey: getListProgramsQueryKey() },
  });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", code: "", description: "", academicYear: "2026-27" });

  const createMutation = useCreateProgram({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListProgramsQueryKey() });
        setOpen(false);
        setForm({ name: "", code: "", description: "", academicYear: "2026-27" });
        toast({ title: "Program created" });
      },
      onError: (err: Error) => toast({ variant: "destructive", title: "Failed", description: err.message }),
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Fellowship Programs</h1>
          <p className="text-muted-foreground">Manage long-term fellowship programs and their specialities.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-orange-500 to-amber-500">
              <Plus className="h-4 w-4 mr-2" /> New Program
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Program</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div>
                <Label>Name</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Long-term Fellowship in Glaucoma" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Code</Label>
                  <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="GLAUC-2026" />
                </div>
                <div>
                  <Label>Academic Year</Label>
                  <Input value={form.academicYear} onChange={(e) => setForm({ ...form, academicYear: e.target.value })} />
                </div>
              </div>
              <div>
                <Label>Description</Label>
                <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
              <Button
                onClick={() => createMutation.mutate({ data: form })}
                disabled={!form.name || !form.code || createMutation.isPending}
              >
                Create Program
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="text-muted-foreground">Loading programs…</div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {programs?.map((p) => (
            <Link key={p.id} href={`/programs/${p.id}`}>
              <Card className="cursor-pointer hover:shadow-md transition border-l-4 border-l-orange-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <BookOpen className="h-4 w-4 text-orange-500" />
                    {p.name}
                  </CardTitle>
                  <div className="text-xs text-muted-foreground font-mono">{p.code} · {p.academicYear}</div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div>
                      <div className="text-xl font-semibold">{p.totalSeats}</div>
                      <div className="text-xs text-muted-foreground flex items-center justify-center gap-1"><GraduationCap className="h-3 w-3" /> Seats</div>
                    </div>
                    <div>
                      <div className="text-xl font-semibold">{p.specialityCount}</div>
                      <div className="text-xs text-muted-foreground">Specialities</div>
                    </div>
                    <div>
                      <div className="text-xl font-semibold">{p.candidateCount}</div>
                      <div className="text-xs text-muted-foreground flex items-center justify-center gap-1"><Users className="h-3 w-3" /> Cands</div>
                    </div>
                  </div>
                  <div className="text-xs text-orange-600 flex items-center gap-1 pt-2 border-t">
                    Open program <ArrowRight className="h-3 w-3" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
