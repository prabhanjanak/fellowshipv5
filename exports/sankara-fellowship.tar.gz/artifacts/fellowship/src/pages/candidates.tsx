import { useMemo, useState } from "react";
import { Link } from "wouter";
import {
  useListCandidates,
  useListPrograms,
  useListUnits,
  getListCandidatesQueryKey,
  getListProgramsQueryKey,
  getListUnitsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search } from "lucide-react";
import { statusColor, statusLabel } from "@/lib/status";

const STATUSES = [
  "registered", "documents_pending", "exam_pending", "exam_completed",
  "interview_pending", "interview_completed", "allocated", "waitlisted", "rejected",
];

export default function CandidatesPage() {
  const [programId, setProgramId] = useState<string>("all");
  const [unitId, setUnitId] = useState<string>("all");
  const [status, setStatus] = useState<string>("all");
  const [search, setSearch] = useState("");

  const params = useMemo(() => {
    const p: Record<string, number | string> = {};
    if (programId !== "all") p["programId"] = Number(programId);
    if (unitId !== "all") p["unitId"] = Number(unitId);
    if (status !== "all") p["status"] = status;
    return Object.keys(p).length > 0 ? p : undefined;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [programId, unitId, status]);

  const { data: candidates, isLoading } = useListCandidates(params, {
    query: { queryKey: getListCandidatesQueryKey(params) },
  });
  const { data: programs } = useListPrograms({ query: { queryKey: getListProgramsQueryKey() } });
  const { data: units } = useListUnits({ query: { queryKey: getListUnitsQueryKey() } });

  const filtered = useMemo(() => {
    if (!candidates) return [];
    const q = search.trim().toLowerCase();
    if (!q) return candidates;
    return candidates.filter((c) =>
      c.fullName.toLowerCase().includes(q) ||
      c.candidateCode.toLowerCase().includes(q) ||
      c.email.toLowerCase().includes(q),
    );
  }, [candidates, search]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Candidates</h1>
        <p className="text-muted-foreground">All registered fellowship applicants across programs.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filter & search</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-4">
            <div className="md:col-span-1">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input className="pl-9" placeholder="Search by name, code, email" value={search} onChange={(e) => setSearch(e.target.value)} />
              </div>
            </div>
            <Select value={programId} onValueChange={setProgramId}>
              <SelectTrigger><SelectValue placeholder="Program" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All programs</SelectItem>
                {programs?.map((p) => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={unitId} onValueChange={setUnitId}>
              <SelectTrigger><SelectValue placeholder="Unit" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All units</SelectItem>
                {units?.map((u) => <SelectItem key={u.id} value={String(u.id)}>{u.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                {STATUSES.map((s) => <SelectItem key={s} value={s}>{statusLabel(s)}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 text-muted-foreground">Loading candidates…</div>
          ) : filtered.length === 0 ? (
            <div className="p-6 text-muted-foreground">No candidates match your filters.</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Unit</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((c) => (
                  <TableRow key={c.id} className="cursor-pointer">
                    <TableCell className="font-mono text-xs">
                      <Link href={`/candidates/${c.id}`}><span className="text-orange-600 hover:underline">{c.candidateCode}</span></Link>
                    </TableCell>
                    <TableCell className="font-medium"><Link href={`/candidates/${c.id}`}>{c.fullName}</Link></TableCell>
                    <TableCell className="text-muted-foreground">{c.email}</TableCell>
                    <TableCell className="text-muted-foreground">{c.phone}</TableCell>
                    <TableCell>{c.unitName ?? <span className="text-muted-foreground">—</span>}</TableCell>
                    <TableCell>
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs border ${statusColor(c.status)}`}>{statusLabel(c.status)}</span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
