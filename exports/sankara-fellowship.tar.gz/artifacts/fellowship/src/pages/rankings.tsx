import { useState } from "react";
import {
  useGetRankings,
  useListPrograms,
  getGetRankingsQueryKey,
  getListProgramsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Trophy } from "lucide-react";

export default function RankingsPage() {
  const [programId, setProgramId] = useState<string>("");
  const { data: programs } = useListPrograms({ query: { queryKey: getListProgramsQueryKey() } });
  const params = programId ? { programId: Number(programId) } : { programId: 0 };
  const { data: rankings, isLoading } = useGetRankings(params, {
    query: { enabled: !!programId, queryKey: getGetRankingsQueryKey(params) },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Candidate Rankings</h1>
        <p className="text-muted-foreground">Live ranking based on MCQ, psychometric, and interview scores.</p>
      </div>
      <Card>
        <CardHeader>
          <Select value={programId} onValueChange={setProgramId}>
            <SelectTrigger className="w-[400px]"><SelectValue placeholder="Select program to rank" /></SelectTrigger>
            <SelectContent>{programs?.map((p) => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}</SelectContent>
          </Select>
        </CardHeader>
        <CardContent className="p-0">
          {!programId ? (
            <div className="p-6 text-muted-foreground">Pick a program to view rankings.</div>
          ) : isLoading ? (
            <div className="p-6 text-muted-foreground">Computing rankings…</div>
          ) : (
            <Table>
              <TableHeader><TableRow>
                <TableHead className="w-[60px]">Rank</TableHead>
                <TableHead>Candidate</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>MCQ</TableHead>
                <TableHead>Psychometric</TableHead>
                <TableHead>Interview</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Top Preference</TableHead>
              </TableRow></TableHeader>
              <TableBody>{rankings?.map((r) => (
                <TableRow key={r.candidateId} className={r.rank <= 10 ? "bg-orange-50/50" : ""}>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      {r.rank <= 3 && <Trophy className={`h-4 w-4 ${r.rank === 1 ? "text-amber-500" : r.rank === 2 ? "text-slate-400" : "text-orange-700"}`} />}
                      <span className="font-semibold">{r.rank}</span>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{r.fullName}</TableCell>
                  <TableCell className="font-mono text-xs">{r.candidateCode}</TableCell>
                  <TableCell>{r.mcqScore.toFixed(1)}</TableCell>
                  <TableCell>{r.psychometricScore.toFixed(1)}</TableCell>
                  <TableCell>{r.interviewScore.toFixed(1)}</TableCell>
                  <TableCell className="font-bold text-orange-700">{r.totalScore.toFixed(1)}</TableCell>
                  <TableCell className="text-muted-foreground">{r.topPreference ?? "—"}</TableCell>
                </TableRow>
              ))}</TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
