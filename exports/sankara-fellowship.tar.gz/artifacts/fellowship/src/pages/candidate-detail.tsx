import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetCandidate,
  useAssignCandidateUnit,
  useListUnits,
  getGetCandidateQueryKey,
  getListCandidatesQueryKey,
  getListUnitsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ChevronLeft, FileText, ListOrdered, ClipboardCheck, User as UserIcon, MapPin } from "lucide-react";
import { statusColor, statusLabel } from "@/lib/status";
import { useToast } from "@/hooks/use-toast";

export default function CandidateDetailPage() {
  const [, params] = useRoute<{ id: string }>("/candidates/:id");
  const id = Number(params?.id);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [unitId, setUnitId] = useState<string>("");

  const { data: candidate, isLoading } = useGetCandidate(id, {
    query: { enabled: !!id, queryKey: getGetCandidateQueryKey(id) },
  });
  const { data: units } = useListUnits({ query: { queryKey: getListUnitsQueryKey() } });

  const assignMutation = useAssignCandidateUnit({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCandidateQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getListCandidatesQueryKey() });
        toast({ title: "Unit assigned" });
      },
    },
  });

  if (isLoading) return <div>Loading…</div>;
  if (!candidate) return <div>Candidate not found.</div>;

  return (
    <div className="space-y-6">
      <Link href="/candidates"><Button variant="ghost" size="sm" className="-ml-2"><ChevronLeft className="h-4 w-4 mr-1" /> All candidates</Button></Link>
      <div className="flex items-start justify-between">
        <div>
          <div className="text-xs uppercase font-mono text-orange-600">{candidate.candidateCode}</div>
          <h1 className="text-3xl font-bold tracking-tight mt-1">{candidate.fullName}</h1>
          <div className="flex items-center gap-3 mt-2 text-muted-foreground">
            <span>{candidate.email}</span>
            <span>·</span>
            <span>{candidate.phone}</span>
            {candidate.unitName && (<><span>·</span><span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {candidate.unitName}</span></>)}
          </div>
        </div>
        <span className={`inline-flex px-3 py-1 rounded-full text-sm border ${statusColor(candidate.status)}`}>{statusLabel(candidate.status)}</span>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card><CardHeader className="pb-1"><CardTitle className="text-xs text-muted-foreground font-normal">MCQ Score</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{candidate.mcqScore?.toFixed(1) ?? "—"}</div></CardContent></Card>
        <Card><CardHeader className="pb-1"><CardTitle className="text-xs text-muted-foreground font-normal">Psychometric</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{candidate.psychometricScore?.toFixed(1) ?? "—"}</div></CardContent></Card>
        <Card><CardHeader className="pb-1"><CardTitle className="text-xs text-muted-foreground font-normal">Interview</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{candidate.interviewScore?.toFixed(1) ?? "—"}</div></CardContent></Card>
        <Card className="bg-gradient-to-br from-orange-50 to-amber-50 border-orange-200"><CardHeader className="pb-1"><CardTitle className="text-xs text-orange-700 font-normal">Total Score</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold text-orange-700">{candidate.totalScore?.toFixed(1) ?? "—"}</div></CardContent></Card>
      </div>

      <Tabs defaultValue="profile">
        <TabsList>
          <TabsTrigger value="profile"><UserIcon className="h-4 w-4 mr-1" /> Profile</TabsTrigger>
          <TabsTrigger value="preferences"><ListOrdered className="h-4 w-4 mr-1" /> Preferences</TabsTrigger>
          <TabsTrigger value="documents"><FileText className="h-4 w-4 mr-1" /> Documents</TabsTrigger>
          <TabsTrigger value="attempts"><ClipboardCheck className="h-4 w-4 mr-1" /> Exam Attempts</TabsTrigger>
          <TabsTrigger value="assignment"><MapPin className="h-4 w-4 mr-1" /> Assignment</TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <Card><CardContent className="grid grid-cols-2 gap-4 pt-6">
            <div><div className="text-xs text-muted-foreground">Date of birth</div><div className="font-medium">{candidate.dateOfBirth ?? "—"}</div></div>
            <div><div className="text-xs text-muted-foreground">Gender</div><div className="font-medium">{candidate.gender ?? "—"}</div></div>
            <div><div className="text-xs text-muted-foreground">Qualification</div><div className="font-medium">{candidate.qualification ?? "—"}</div></div>
            <div><div className="text-xs text-muted-foreground">College</div><div className="font-medium">{candidate.collegeName ?? "—"}</div></div>
            <div className="col-span-2"><div className="text-xs text-muted-foreground">Address</div><div className="font-medium">{candidate.address ?? "—"}</div></div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="preferences">
          <Card><CardContent className="pt-6">
            {candidate.preferences && candidate.preferences.length > 0 ? (
              <ol className="space-y-2">
                {candidate.preferences.map((p) => (
                  <li key={p.id} className="flex items-center gap-3 p-2 rounded border">
                    <span className="w-7 h-7 rounded-full bg-orange-100 text-orange-700 text-sm font-bold flex items-center justify-center">{p.preferenceOrder}</span>
                    <div><div className="font-medium">{p.specialityName}</div><div className="text-xs text-muted-foreground">{p.programName}</div></div>
                  </li>
                ))}
              </ol>
            ) : <div className="text-muted-foreground">No preferences submitted yet.</div>}
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="documents">
          <Card><CardContent className="p-0">
            {candidate.documents && candidate.documents.length > 0 ? (
              <Table><TableHeader><TableRow><TableHead>Type</TableHead><TableHead>File</TableHead><TableHead>Uploaded</TableHead></TableRow></TableHeader>
                <TableBody>{candidate.documents.map((d) => (
                  <TableRow key={d.id}><TableCell>{d.docType}</TableCell><TableCell className="font-mono text-xs">{d.fileName}</TableCell><TableCell className="text-muted-foreground text-sm">{new Date(d.uploadedAt).toLocaleString()}</TableCell></TableRow>
                ))}</TableBody>
              </Table>
            ) : <div className="p-6 text-muted-foreground">No documents uploaded.</div>}
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="attempts">
          <Card><CardContent className="p-0">
            {candidate.attempts && candidate.attempts.length > 0 ? (
              <Table><TableHeader><TableRow><TableHead>Exam</TableHead><TableHead>Kind</TableHead><TableHead>Score</TableHead><TableHead>Submitted</TableHead></TableRow></TableHeader>
                <TableBody>{candidate.attempts.map((a) => (
                  <TableRow key={a.id}>
                    <TableCell className="font-medium">{a.examTitle}</TableCell>
                    <TableCell><span className="text-xs uppercase tracking-wide text-muted-foreground">{a.examKind}</span></TableCell>
                    <TableCell>{a.score != null ? `${a.score.toFixed(1)} / ${a.maxScore?.toFixed(1) ?? "—"}` : "—"}</TableCell>
                    <TableCell className="text-muted-foreground text-sm">{a.submittedAt ? new Date(a.submittedAt).toLocaleString() : "In progress"}</TableCell>
                  </TableRow>
                ))}</TableBody>
              </Table>
            ) : <div className="p-6 text-muted-foreground">No exam attempts yet.</div>}
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="assignment">
          <Card><CardContent className="pt-6 space-y-4">
            <div><div className="text-xs text-muted-foreground">Current unit</div><div className="font-medium">{candidate.unitName ?? "Not assigned"}</div></div>
            <div className="flex gap-2 items-end">
              <div className="flex-1"><div className="text-xs text-muted-foreground mb-1">Assign to unit</div>
                <Select value={unitId} onValueChange={setUnitId}>
                  <SelectTrigger><SelectValue placeholder="Select unit" /></SelectTrigger>
                  <SelectContent>{units?.map((u) => <SelectItem key={u.id} value={String(u.id)}>{u.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <Button onClick={() => unitId && assignMutation.mutate({ candidateId: id, data: { unitId: Number(unitId) } })} disabled={!unitId || assignMutation.isPending}>Assign</Button>
            </div>
          </CardContent></Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
