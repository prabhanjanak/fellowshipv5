import { Link } from "wouter";
import {
  useListCandidates,
  useGetExamProgress,
  useListUnits,
  getListCandidatesQueryKey,
  getGetExamProgressQueryKey,
  getListUnitsQueryKey,
} from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { statusColor, statusLabel } from "@/lib/status";

export default function CoordinatorPage() {
  const { user } = useAuth();
  const { data: candidates, isLoading } = useListCandidates(undefined, { query: { queryKey: getListCandidatesQueryKey() } });
  const params = user?.unitId ? { unitId: user.unitId } : undefined;
  const { data: progress } = useGetExamProgress(params, { query: { queryKey: getGetExamProgressQueryKey(params) } });
  const { data: units } = useListUnits({ query: { queryKey: getListUnitsQueryKey() } });
  const myUnit = units?.find((u) => u.id === user?.unitId);

  return (
    <div className="space-y-6">
      <div>
        <div className="text-xs uppercase tracking-wider text-orange-600 font-semibold">Exam Coordinator</div>
        <h1 className="text-3xl font-bold tracking-tight mt-1">{myUnit?.name ?? "Your Unit"}</h1>
        <p className="text-muted-foreground">{myUnit ? `${myUnit.city}, ${myUnit.state} · ` : ""}Manage candidate exam progress for your unit.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Candidates in unit</CardTitle></CardHeader><CardContent><div className="text-3xl font-bold">{candidates?.length ?? 0}</div></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Exams underway</CardTitle></CardHeader><CardContent><div className="text-3xl font-bold">{progress?.length ?? 0}</div></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Avg completion</CardTitle></CardHeader><CardContent>
          <div className="text-3xl font-bold">
            {progress && progress.length > 0
              ? Math.round((progress.reduce((s, p) => s + (p.totalCandidates ? p.completedCount / p.totalCandidates : 0), 0) / progress.length) * 100) + "%"
              : "—"}
          </div></CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>Exam Progress</CardTitle></CardHeader>
        <CardContent>
          {progress && progress.length > 0 ? (
            <div className="h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={progress}>
                  <XAxis dataKey="examTitle" stroke="#888" fontSize={11} />
                  <YAxis stroke="#888" fontSize={11} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="startedCount" name="Started" fill="hsl(35 90% 65%)" radius={[4,4,0,0]} />
                  <Bar dataKey="completedCount" name="Completed" fill="hsl(20 90% 50%)" radius={[4,4,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : <div className="text-muted-foreground">No exam activity yet for this unit.</div>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Candidates</CardTitle></CardHeader>
        <CardContent className="p-0">
          {isLoading ? <div className="p-6 text-muted-foreground">Loading…</div> : (
            <Table>
              <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Name</TableHead><TableHead>Email</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
              <TableBody>{candidates?.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="font-mono text-xs"><Link href={`/candidates/${c.id}`}><span className="text-orange-600 hover:underline">{c.candidateCode}</span></Link></TableCell>
                  <TableCell className="font-medium">{c.fullName}</TableCell>
                  <TableCell className="text-muted-foreground">{c.email}</TableCell>
                  <TableCell><span className={`inline-flex px-2 py-0.5 rounded-full text-xs border ${statusColor(c.status)}`}>{statusLabel(c.status)}</span></TableCell>
                </TableRow>
              ))}</TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
