import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetMyCandidate,
  useUpdateMyCandidate,
  getGetMyCandidateQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export default function ProfilePage() {
  const { data: cand } = useGetMyCandidate({ query: { queryKey: getGetMyCandidateQueryKey() } });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [form, setForm] = useState({
    fullName: "", phone: "", dateOfBirth: "", gender: "", qualification: "", collegeName: "", address: "",
  });

  useEffect(() => {
    if (cand) {
      setForm({
        fullName: cand.fullName,
        phone: cand.phone,
        dateOfBirth: cand.dateOfBirth ?? "",
        gender: cand.gender ?? "",
        qualification: cand.qualification ?? "",
        collegeName: cand.collegeName ?? "",
        address: cand.address ?? "",
      });
    }
  }, [cand]);

  const updateMutation = useUpdateMyCandidate({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMyCandidateQueryKey() });
        toast({ title: "Profile updated" });
      },
    },
  });

  if (!cand) return <div>Loading…</div>;

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Your Profile</h1>
        <p className="text-muted-foreground">Keep your personal details up to date.</p>
      </div>
      <Card>
        <CardHeader><CardTitle>Personal information</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div><Label>Full name</Label><Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></div>
            <div><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div><Label>Date of birth</Label><Input type="date" value={form.dateOfBirth} onChange={(e) => setForm({ ...form, dateOfBirth: e.target.value })} /></div>
            <div><Label>Gender</Label><Input value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })} /></div>
            <div><Label>Qualification</Label><Input value={form.qualification} onChange={(e) => setForm({ ...form, qualification: e.target.value })} /></div>
            <div><Label>College</Label><Input value={form.collegeName} onChange={(e) => setForm({ ...form, collegeName: e.target.value })} /></div>
          </div>
          <div><Label>Address</Label><Textarea rows={3} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
          <Button onClick={() => updateMutation.mutate({ data: form })} disabled={updateMutation.isPending} className="bg-gradient-to-r from-orange-500 to-amber-500">Save changes</Button>
        </CardContent>
      </Card>
    </div>
  );
}
