import { useEffect, useMemo, useRef, useState } from "react";
import { useRoute, Link, useLocation } from "wouter";
import {
  useStartAttempt,
  useSaveAnswer,
  useSubmitAttempt,
  AttemptInProgress,
  AttemptResult,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, ChevronLeft, ChevronRight, CheckCircle2, Maximize2, AlertTriangle, ShieldAlert } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

function fmtTime(ms: number) {
  if (ms <= 0) return "00:00";
  const totalSec = Math.floor(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default function StudentExamRunnerPage() {
  const [, params] = useRoute<{ examId: string }>("/student/exam/:examId");
  const examId = Number(params?.examId);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [attempt, setAttempt] = useState<AttemptInProgress | null>(null);
  const [result, setResult] = useState<AttemptResult | null>(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [answers, setAnswers] = useState<Record<number, { optionId?: number; numericValue?: number }>>({});
  const startedRef = useRef(false);
  const submittedRef = useRef(false);

  // Anti-cheat state
  const [examStarted, setExamStarted] = useState(false);
  const [violations, setViolations] = useState(0);
  const [warning, setWarning] = useState<string | null>(null);
  const [isFlagged, setIsFlagged] = useState(false);

  const recordViolation = (reason: string) => {
    setViolations((v) => {
      const next = v + 1;
      if (next === 1) setWarning(`Warning 1 of 3: ${reason}. Do not switch tabs, exit fullscreen, or copy/paste during the exam.`);
      else if (next === 2) setWarning(`Final warning (2 of 3): ${reason}. The next violation will flag your attempt for review.`);
      else setIsFlagged(true);
      return next;
    });
  };

  const enterFullscreen = async () => {
    try {
      await document.documentElement.requestFullscreen();
      setExamStarted(true);
    } catch {
      toast({ variant: "destructive", title: "Fullscreen required", description: "Please allow fullscreen to start the exam." });
    }
  };

  // Anti-cheat listeners
  useEffect(() => {
    if (!examStarted || result) return;

    const onVisibility = () => {
      if (document.visibilityState === "hidden") recordViolation("Tab switch detected");
    };
    const onFullscreenChange = () => {
      if (!document.fullscreenElement) recordViolation("Fullscreen exited");
    };
    const onCtxMenu = (e: MouseEvent) => { e.preventDefault(); };
    const onCopy = (e: ClipboardEvent) => { e.preventDefault(); recordViolation("Copy attempt blocked"); };
    const onPaste = (e: ClipboardEvent) => { e.preventDefault(); recordViolation("Paste attempt blocked"); };
    const onCut = (e: ClipboardEvent) => { e.preventDefault(); };
    const onKey = (e: KeyboardEvent) => {
      // Block common DevTools / printing shortcuts
      if (e.key === "F12") { e.preventDefault(); recordViolation("DevTools shortcut blocked"); }
      if ((e.ctrlKey || e.metaKey) && ["p", "s", "u"].includes(e.key.toLowerCase())) { e.preventDefault(); }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && ["i", "j", "c"].includes(e.key.toLowerCase())) {
        e.preventDefault(); recordViolation("DevTools shortcut blocked");
      }
    };

    document.addEventListener("visibilitychange", onVisibility);
    document.addEventListener("fullscreenchange", onFullscreenChange);
    document.addEventListener("contextmenu", onCtxMenu);
    document.addEventListener("copy", onCopy);
    document.addEventListener("paste", onPaste);
    document.addEventListener("cut", onCut);
    document.addEventListener("keydown", onKey);

    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      document.removeEventListener("fullscreenchange", onFullscreenChange);
      document.removeEventListener("contextmenu", onCtxMenu);
      document.removeEventListener("copy", onCopy);
      document.removeEventListener("paste", onPaste);
      document.removeEventListener("cut", onCut);
      document.removeEventListener("keydown", onKey);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [examStarted, result]);

  // Exit fullscreen when exam is over
  useEffect(() => {
    if (result && document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    }
  }, [result]);

  const startMutation = useStartAttempt({
    mutation: {
      onSuccess: (data) => {
        setAttempt(data);
        const init: Record<number, { optionId?: number; numericValue?: number }> = {};
        for (const a of data.savedAnswers ?? []) {
          init[a.questionId] = { optionId: a.optionId ?? undefined, numericValue: a.numericValue ?? undefined };
        }
        setAnswers(init);
      },
      onError: (e: Error) => toast({ variant: "destructive", title: "Cannot start exam", description: e.message }),
    },
  });

  const saveMutation = useSaveAnswer();

  const submitMutation = useSubmitAttempt({
    mutation: {
      onSuccess: (data) => { setResult(data); },
      onError: (e: Error) => toast({ variant: "destructive", title: "Submit failed", description: e.message }),
    },
  });

  useEffect(() => {
    if (!examId || startedRef.current) return;
    startedRef.current = true;
    startMutation.mutate({ data: { examId } });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [examId]);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const deadlineMs = attempt ? new Date(attempt.deadline).getTime() : 0;
  const remaining = deadlineMs - now;

  useEffect(() => {
    if (!attempt || result || submittedRef.current) return;
    if (remaining <= 0) {
      submittedRef.current = true;
      submitMutation.mutate({ attemptId: attempt.id });
    }
  }, [remaining, attempt, result, submitMutation]);

  const currentQ = useMemo(() => attempt?.questions?.[currentIdx], [attempt, currentIdx]);

  const setAnswer = (questionId: number, value: { optionId?: number; numericValue?: number }) => {
    setAnswers((a) => ({ ...a, [questionId]: value }));
    if (attempt) {
      saveMutation.mutate({
        attemptId: attempt.id,
        data: { questionId, optionId: value.optionId ?? null, numericValue: value.numericValue ?? null },
      });
    }
  };

  const handleSubmit = () => {
    if (!attempt || submittedRef.current) return;
    submittedRef.current = true;
    submitMutation.mutate({ attemptId: attempt.id });
  };

  if (result) {
    const pct = result.maxScore && result.maxScore > 0 ? Math.round((result.score / result.maxScore) * 100) : 0;
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 flex items-center justify-center p-6">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center"><CheckCircle2 className="h-16 w-16 text-emerald-500 mx-auto" /><CardTitle className="mt-4">Exam Submitted</CardTitle></CardHeader>
          <CardContent className="text-center space-y-4">
            <div>
              <div className="text-5xl font-bold text-orange-700">{result.score.toFixed(1)}<span className="text-lg text-muted-foreground"> / {result.maxScore?.toFixed(1) ?? "—"}</span></div>
              <div className="text-sm text-muted-foreground mt-1">{pct}% score</div>
            </div>
            <Button className="w-full bg-gradient-to-r from-orange-500 to-amber-500" onClick={() => setLocation("/student/exams")}>Back to exams</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!attempt) {
    return <div className="min-h-screen flex items-center justify-center"><div className="text-muted-foreground">Starting exam…</div></div>;
  }

  if (!examStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 flex items-center justify-center p-6">
        <Card className="max-w-lg w-full">
          <CardHeader className="text-center">
            <ShieldAlert className="h-12 w-12 text-orange-500 mx-auto" />
            <CardTitle className="mt-3">Exam Rules — Read Before Starting</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-sm space-y-2 text-muted-foreground">
              <p><span className="font-semibold text-foreground">Fullscreen required.</span> The exam must be taken in fullscreen mode.</p>
              <p><span className="font-semibold text-foreground">No tab switching.</span> Switching tabs, opening windows, or exiting fullscreen counts as a violation.</p>
              <p><span className="font-semibold text-foreground">No copy / paste / right-click.</span> These actions are blocked and tracked.</p>
              <p><span className="font-semibold text-foreground">Three strikes.</span> 1st: warning · 2nd: final warning · 3rd or more: your attempt is flagged for review.</p>
              <p><span className="font-semibold text-foreground">Timer:</span> {Math.round((deadlineMs - Date.now()) / 60000)} minutes remaining. Auto-submits when time runs out.</p>
            </div>
            <Button className="w-full bg-gradient-to-r from-orange-500 to-amber-500" onClick={enterFullscreen}>
              <Maximize2 className="h-4 w-4 mr-2" /> Enter Fullscreen & Start
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const total = attempt.questions?.length ?? 0;
  const answeredCount = Object.values(answers).filter((a) => a.optionId != null || a.numericValue != null).length;

  return (
    <div className="min-h-screen bg-slate-50 select-none" style={{ userSelect: "none" }}>
      {warning && (
        <div className="bg-amber-100 border-b border-amber-300 text-amber-900 px-6 py-3 flex items-start justify-between gap-4">
          <div className="flex items-start gap-2 text-sm">
            <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
            <div>{warning}</div>
          </div>
          <button onClick={() => setWarning(null)} className="text-amber-700 hover:text-amber-900 text-sm font-medium">Dismiss</button>
        </div>
      )}
      {isFlagged && (
        <div className="bg-rose-100 border-b border-rose-300 text-rose-900 px-6 py-3 flex items-center gap-2 text-sm">
          <ShieldAlert className="h-4 w-4 shrink-0" />
          <div>Your attempt has been flagged for review due to repeated violations. Please continue and submit as normal — your coordinator has been notified.</div>
        </div>
      )}
      <header className="bg-white border-b sticky top-0 z-10 shadow-sm">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-orange-600 uppercase tracking-wider font-semibold">{attempt.examKind.replace(/_/g, " ")}</div>
            <h1 className="text-lg font-bold">{attempt.examTitle}</h1>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-xs text-muted-foreground">Violations: <span className={`font-semibold ${violations === 0 ? "text-emerald-600" : violations < 3 ? "text-amber-600" : "text-rose-600"}`}>{violations}</span></div>
            <div className={`flex items-center gap-2 px-4 py-2 rounded-lg border ${remaining < 60_000 ? "bg-rose-50 border-rose-200 text-rose-700" : "bg-orange-50 border-orange-200 text-orange-700"}`}>
              <Clock className="h-4 w-4" />
              <span className="font-mono font-semibold text-lg tabular-nums">{fmtTime(remaining)}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">Question <span className="font-semibold text-foreground">{currentIdx + 1}</span> of {total}</div>
          <div className="text-sm text-muted-foreground">{answeredCount} answered</div>
        </div>

        {currentQ && (
          <Card>
            <CardHeader><CardTitle className="text-lg leading-relaxed">{currentQ.body}</CardTitle></CardHeader>
            <CardContent>
              {currentQ.kind === "psychometric_scale" ? (
                <div className="grid grid-cols-5 gap-2">
                  {currentQ.options.map((o) => {
                    const val = Number(o.body);
                    const selected = answers[currentQ.id]?.numericValue === val;
                    return (
                      <button
                        key={o.id}
                        onClick={() => setAnswer(currentQ.id, { numericValue: val, optionId: o.id })}
                        className={`p-4 rounded-lg border-2 text-center transition ${selected ? "border-orange-500 bg-orange-50" : "border-slate-200 hover:border-orange-300"}`}
                      >
                        <div className="text-2xl font-bold">{o.body}</div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="space-y-2">
                  {currentQ.options.map((o) => {
                    const selected = answers[currentQ.id]?.optionId === o.id;
                    return (
                      <button
                        key={o.id}
                        onClick={() => setAnswer(currentQ.id, { optionId: o.id })}
                        className={`w-full p-3 rounded-lg border-2 text-left transition ${selected ? "border-orange-500 bg-orange-50" : "border-slate-200 hover:border-orange-300"}`}
                      >
                        {o.body}
                      </button>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        <div className="flex items-center justify-between pt-2">
          <Button variant="outline" disabled={currentIdx === 0} onClick={() => setCurrentIdx(currentIdx - 1)}><ChevronLeft className="h-4 w-4 mr-1" /> Previous</Button>
          {currentIdx < total - 1 ? (
            <Button onClick={() => setCurrentIdx(currentIdx + 1)} className="bg-gradient-to-r from-orange-500 to-amber-500">Next <ChevronRight className="h-4 w-4 ml-1" /></Button>
          ) : (
            <Button onClick={handleSubmit} className="bg-emerald-600 hover:bg-emerald-700" disabled={submitMutation.isPending}>Submit Exam <CheckCircle2 className="h-4 w-4 ml-1" /></Button>
          )}
        </div>

        <div className="grid grid-cols-10 gap-1 pt-4">
          {attempt.questions?.map((q, idx) => {
            const isAnswered = answers[q.id]?.optionId != null || answers[q.id]?.numericValue != null;
            const isCurrent = idx === currentIdx;
            return (
              <button key={q.id} onClick={() => setCurrentIdx(idx)}
                className={`h-8 rounded text-xs font-semibold transition ${isCurrent ? "bg-orange-500 text-white" : isAnswered ? "bg-emerald-100 text-emerald-700" : "bg-slate-200 text-slate-500"}`}>
                {idx + 1}
              </button>
            );
          })}
        </div>

        <div className="text-center pt-4">
          <Link href="/student/exams"><Button variant="ghost" size="sm">Exit (your progress is saved)</Button></Link>
        </div>
      </main>
    </div>
  );
}
