import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListUsers,
  useCreateUser,
  useListUnits,
  useListPrograms,
  getListUsersQueryKey,
  getListUnitsQueryKey,
  getListProgramsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ROLES = [
  { value: "program_admin", label: "Program Admin" },
  { value: "exam_coordinator", label: "Exam Coordinator" },
  { value: "doctor", label: "Doctor" },
];

export default function StaffPage() {
  const { data: users, isLoading } = useListUsers(undefined, { query: { queryKey: getListUsersQueryKey() } });
  const { data: units } = useListUnits({ query: { queryKey: getListUnitsQueryKey() } });
  const { data: programs } = useListPrograms({ query: { queryKey: getListProgramsQueryKey() } });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<{ email: string; fullName: string; password: string; role: string; unitId: string; programId: string }>({
    email: "", fullName: "", password: "", role: "program_admin", unitId: "", programId: "",
  });

  const createMutation = useCreateUser({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
        setOpen(false);
        setForm({ email: "", fullName: "", password: "", role: "program_admin", unitId: "", programId: "" });
        toast({ title: "Staff user created" });
      },
      onError: (e: Error) => toast({ variant: "destructive", title: "Failed", description: e.message }),
    },
  });

  const submit = () => {
    const payload: Record<string, string | number | null> = {
      email: form.email,
      fullName: form.fullName,
      password: form.password,
      role: form.role,
    };
    if (form.role === "exam_coordinator" || form.role === "doctor") payload["unitId"] = form.unitId ? Number(form.unitId) : null;
    if (form.role === "program_admin") payload["programId"] = form.programId ? Number(form.programId) : null;
    createMutation.mutate({ data: payload as never });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Staff Users</h1>
          <p className="text-muted-foreground">Program admins, exam coordinators, and interview doctors.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="bg-gradient-to-r from-orange-500 to-amber-500"><Plus className="h-4 w-4 mr-2" /> Add Staff</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Create Staff User</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Full name</Label><Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                <div><Label>Password</Label><Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
              </div>
              <div><Label>Role</Label>
                <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{ROLES.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              {(form.role === "exam_coordinator" || form.role === "doctor") && (
                <div><Label>Unit</Label>
                  <Select value={form.unitId} onValueChange={(v) => setForm({ ...form, unitId: v })}>
                    <SelectTrigger><SelectValue placeholder="Select unit" /></SelectTrigger>
                    <SelectContent>{units?.map((u) => <SelectItem key={u.id} value={String(u.id)}>{u.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              )}
              {form.role === "program_admin" && (
                <div><Label>Program (optional)</Label>
                  <Select value={form.programId} onValueChange={(v) => setForm({ ...form, programId: v })}>
                    <SelectTrigger><SelectValue placeholder="Select program" /></SelectTrigger>
                    <SelectContent>{programs?.map((p) => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={submit} disabled={createMutation.isPending || !form.email || !form.password}>Create</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card><CardHeader><CardTitle>All Users</CardTitle></CardHeader><CardContent className="p-0">
        {isLoading ? <div className="p-6 text-muted-foreground">Loading…</div> : (
          <Table>
            <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Email</TableHead><TableHead>Role</TableHead><TableHead>Unit</TableHead><TableHead>Program</TableHead></TableRow></TableHeader>
            <TableBody>{users?.map((u) => (
              <TableRow key={u.id}>
                <TableCell className="font-medium">{u.fullName}</TableCell>
                <TableCell className="text-muted-foreground">{u.email}</TableCell>
                <TableCell><span className="text-xs uppercase tracking-wide text-orange-700 font-semibold">{u.role.replace(/_/g, " ")}</span></TableCell>
                <TableCell>{u.unitName ?? "—"}</TableCell>
                <TableCell>{u.programName ?? "—"}</TableCell>
              </TableRow>
            ))}</TableBody>
          </Table>
        )}
      </CardContent></Card>
    </div>
  );
}
