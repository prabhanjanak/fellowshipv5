import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListMyDocuments,
  useUploadMyDocument,
  getListMyDocumentsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const DOC_TYPES = [
  "Aadhar Card", "MBBS Certificate", "MS Certificate", "ID Photo", "Resume / CV", "Other",
];

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const idx = result.indexOf(",");
      resolve(idx >= 0 ? result.slice(idx + 1) : result);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function StudentDocumentsPage() {
  const { data: docs, isLoading } = useListMyDocuments({ query: { queryKey: getListMyDocumentsQueryKey() } });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [docType, setDocType] = useState<string>("Aadhar Card");
  const [file, setFile] = useState<File | null>(null);

  const uploadMutation = useUploadMyDocument({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMyDocumentsQueryKey() });
        setFile(null);
        toast({ title: "Document uploaded" });
      },
    },
  });

  const handleUpload = async () => {
    if (!file) return;
    const contentBase64 = await fileToBase64(file);
    uploadMutation.mutate({ data: { docType, fileName: file.name, contentBase64 } });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Your Documents</h1>
        <p className="text-muted-foreground">Upload identity, qualification, and supporting documents.</p>
      </div>

      <Card>
        <CardHeader><CardTitle>Upload a document</CardTitle></CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-3">
            <div>
              <Label>Document type</Label>
              <Select value={docType} onValueChange={setDocType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{DOC_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="md:col-span-2">
              <Label>File</Label>
              <Input type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
            </div>
          </div>
          <Button className="mt-4 bg-gradient-to-r from-orange-500 to-amber-500" disabled={!file || uploadMutation.isPending} onClick={handleUpload}>
            <Upload className="h-4 w-4 mr-2" /> Upload
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Uploaded</CardTitle></CardHeader>
        <CardContent className="p-0">
          {isLoading ? <div className="p-6 text-muted-foreground">Loading…</div> : !docs || docs.length === 0 ? (
            <div className="p-6 text-muted-foreground">No documents uploaded yet.</div>
          ) : (
            <Table>
              <TableHeader><TableRow><TableHead>Type</TableHead><TableHead>File</TableHead><TableHead>Uploaded</TableHead></TableRow></TableHeader>
              <TableBody>{docs.map((d) => (
                <TableRow key={d.id}>
                  <TableCell className="font-medium">{d.docType}</TableCell>
                  <TableCell className="font-mono text-xs">{d.fileName}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{new Date(d.uploadedAt).toLocaleString()}</TableCell>
                </TableRow>
              ))}</TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
