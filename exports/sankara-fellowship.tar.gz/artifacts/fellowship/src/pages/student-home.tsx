import { Link } from "wouter";
import {
  useGetMyCandidate,
  useListMyAttempts,
  useListMyDocuments,
  useListMyPreferences,
  getGetMyCandidateQueryKey,
  getListMyAttemptsQueryKey,
  getListMyDocumentsQueryKey,
  getListMyPreferencesQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, FileText, ListOrdered, ClipboardCheck, GraduationCap, User as UserIcon } from "lucide-react";
import { statusColor, statusLabel } from "@/lib/status";

export default function StudentHomePage() {
  const { data: cand } = useGetMyCandidate({ query: { queryKey: getGetMyCandidateQueryKey() } });
  const { data: attempts } = useListMyAttempts({ query: { queryKey: getListMyAttemptsQueryKey() } });
  const { data: docs } = useListMyDocuments({ query: { queryKey: getListMyDocumentsQueryKey() } });
  const { data: prefs } = useListMyPreferences({ query: { queryKey: getListMyPreferencesQueryKey() } });

  if (!cand) return <div>Loading…</div>;
  const completedAttempts = attempts?.filter((a) => a.submittedAt).length ?? 0;

  const links = [
    { href: "/student/exams", title: "Exams", desc: `${completedAttempts} completed`, icon: ClipboardCheck },
    { href: "/student/preferences", title: "Preferences", desc: `${prefs?.length ?? 0} set`, icon: ListOrdered },
    { href: "/student/documents", title: "Documents", desc: `${docs?.length ?? 0} uploaded`, icon: FileText },
    { href: "/student/allocation", title: "Allocation", desc: cand.status === "allocated" || cand.status === "waitlisted" ? "View result" : "Pending", icon: GraduationCap },
  ];

  return (
    <div className="space-y-6">
      <div className="rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 text-white p-6 shadow">
        <div className="text-xs uppercase tracking-wider opacity-80">Welcome back</div>
        <div className="flex items-end justify-between mt-1">
          <div>
            <h1 className="text-3xl font-bold">{cand.fullName}</h1>
            <div className="text-sm opacity-90 mt-1 font-mono">{cand.candidateCode}</div>
          </div>
          <div className="text-right">
            <span className={`inline-flex px-3 py-1 rounded-full text-sm border bg-white/95 ${statusColor(cand.status)}`}>{statusLabel(cand.status)}</span>
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {links.map((l) => {
          const Icon = l.icon;
          return (
            <Link key={l.href} href={l.href}>
              <Card className="cursor-pointer hover:shadow-md transition border-l-4 border-l-orange-500">
                <CardHeader className="pb-2"><CardTitle className="flex items-center gap-2 text-base"><Icon className="h-4 w-4 text-orange-500" /> {l.title}</CardTitle></CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground">{l.desc}</div>
                  <div className="text-xs text-orange-600 flex items-center gap-1 pt-2 mt-2 border-t">Open <ArrowRight className="h-3 w-3" /></div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>

      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><UserIcon className="h-4 w-4" /> Your profile</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-2 gap-4">
          <div><div className="text-xs text-muted-foreground">Email</div><div className="font-medium">{cand.email}</div></div>
          <div><div className="text-xs text-muted-foreground">Phone</div><div className="font-medium">{cand.phone}</div></div>
          <div><div className="text-xs text-muted-foreground">Qualification</div><div className="font-medium">{cand.qualification ?? "—"}</div></div>
          <div><div className="text-xs text-muted-foreground">College</div><div className="font-medium">{cand.collegeName ?? "—"}</div></div>
        </CardContent>
      </Card>
    </div>
  );
}
