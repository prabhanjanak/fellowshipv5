import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetExam,
  useListExamQuestions,
  useCreateQuestion,
  useBulkUploadQuestions,
  getGetExamQueryKey,
  getListExamQuestionsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ChevronLeft, Plus, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ExamDetailPage() {
  const [, params] = useRoute<{ id: string }>("/exams/:id");
  const id = Number(params?.id);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: exam } = useGetExam(id, { query: { enabled: !!id, queryKey: getGetExamQueryKey(id) } });
  const { data: questions, isLoading } = useListExamQuestions(id, { query: { enabled: !!id, queryKey: getListExamQuestionsQueryKey(id) } });

  const [qOpen, setQOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkText, setBulkText] = useState("");
  const [qForm, setQForm] = useState({
    body: "", marks: 1, optA: "", optB: "", optC: "", optD: "", correct: "A",
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: getListExamQuestionsQueryKey(id) });
    queryClient.invalidateQueries({ queryKey: getGetExamQueryKey(id) });
  };

  const createMutation = useCreateQuestion({
    mutation: {
      onSuccess: () => {
        invalidate();
        setQOpen(false);
        setQForm({ body: "", marks: 1, optA: "", optB: "", optC: "", optD: "", correct: "A" });
        toast({ title: "Question added" });
      },
    },
  });

  const bulkMutation = useBulkUploadQuestions({
    mutation: {
      onSuccess: (data) => {
        invalidate();
        setBulkOpen(false);
        setBulkText("");
        toast({ title: "Bulk upload complete", description: `${data.inserted} questions added` });
      },
    },
  });

  const submitQuestion = () => {
    const isPsychoScale = exam?.kind === "psychometric_scale";
    if (isPsychoScale) {
      createMutation.mutate({
        examId: id,
        data: {
          kind: "psychometric_scale",
          body: qForm.body,
          marks: 5,
          rule: { min: 1, max: 5, labels: ["Strongly disagree", "Disagree", "Neutral", "Agree", "Strongly agree"] },
          options: [1, 2, 3, 4, 5].map((n) => ({ body: String(n), isCorrect: false, score: n })),
        },
      });
      return;
    }
    createMutation.mutate({
      examId: id,
      data: {
        kind: exam?.kind ?? "mcq",
        body: qForm.body,
        marks: qForm.marks,
        options: [
          { body: qForm.optA, isCorrect: qForm.correct === "A" },
          { body: qForm.optB, isCorrect: qForm.correct === "B" },
          { body: qForm.optC, isCorrect: qForm.correct === "C" },
          { body: qForm.optD, isCorrect: qForm.correct === "D" },
        ],
      },
    });
  };

  const submitBulk = () => {
    const lines = bulkText.split("\n").map((l) => l.trim()).filter(Boolean);
    const rows = lines.map((line) => {
      const parts = line.split(",").map((p) => p.trim());
      return { body: parts[0] ?? "", optionA: parts[1] ?? "", optionB: parts[2] ?? "", optionC: parts[3] ?? "", optionD: parts[4] ?? "", correct: parts[5] ?? "A" };
    });
    bulkMutation.mutate({ examId: id, data: { rows } });
  };

  if (!exam) return <div>Loading…</div>;

  return (
    <div className="space-y-6">
      <Link href="/exams"><Button variant="ghost" size="sm" className="-ml-2"><ChevronLeft className="h-4 w-4 mr-1" /> All exams</Button></Link>
      <div className="flex items-end justify-between">
        <div>
          <div className="text-xs text-orange-600 font-semibold uppercase tracking-wider">{exam.kind.replace(/_/g, " ")}</div>
          <h1 className="text-3xl font-bold tracking-tight mt-1">{exam.title}</h1>
          <p className="text-muted-foreground max-w-2xl mt-1">{exam.description}</p>
          <div className="flex gap-4 mt-2 text-sm text-muted-foreground">
            <span>{exam.durationMinutes} min</span><span>·</span>
            <span>{exam.totalQuestions} questions per attempt</span><span>·</span>
            <span>{exam.questionCount} questions in pool</span>
          </div>
        </div>
        <div className="flex gap-2">
          <Dialog open={bulkOpen} onOpenChange={setBulkOpen}>
            <DialogTrigger asChild><Button variant="outline"><Upload className="h-4 w-4 mr-2" /> Bulk Upload</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Bulk Upload MCQ Questions</DialogTitle></DialogHeader>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Format per line: <span className="font-mono">question, A, B, C, D, correct (A/B/C/D)</span></p>
                <Textarea rows={12} value={bulkText} onChange={(e) => setBulkText(e.target.value)} placeholder="What is the most common cause of CRAO?, Embolism, Vasculitis, HTN, Diabetes, A" />
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setBulkOpen(false)}>Cancel</Button>
                <Button onClick={submitBulk} disabled={bulkMutation.isPending || !bulkText.trim()}>Upload</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          <Dialog open={qOpen} onOpenChange={setQOpen}>
            <DialogTrigger asChild><Button className="bg-gradient-to-r from-orange-500 to-amber-500"><Plus className="h-4 w-4 mr-2" /> Add Question</Button></DialogTrigger>
            <DialogContent className="max-w-xl">
              <DialogHeader><DialogTitle>Add Question</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Question text</Label><Textarea value={qForm.body} onChange={(e) => setQForm({ ...qForm, body: e.target.value })} rows={3} /></div>
                {exam.kind !== "psychometric_scale" && (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div><Label>Option A</Label><Input value={qForm.optA} onChange={(e) => setQForm({ ...qForm, optA: e.target.value })} /></div>
                      <div><Label>Option B</Label><Input value={qForm.optB} onChange={(e) => setQForm({ ...qForm, optB: e.target.value })} /></div>
                      <div><Label>Option C</Label><Input value={qForm.optC} onChange={(e) => setQForm({ ...qForm, optC: e.target.value })} /></div>
                      <div><Label>Option D</Label><Input value={qForm.optD} onChange={(e) => setQForm({ ...qForm, optD: e.target.value })} /></div>
                    </div>
                    <div className="flex gap-3 items-end">
                      <div><Label>Correct</Label>
                        <select className="border rounded px-2 py-1.5" value={qForm.correct} onChange={(e) => setQForm({ ...qForm, correct: e.target.value })}>
                          {["A","B","C","D"].map((l) => <option key={l} value={l}>{l}</option>)}
                        </select>
                      </div>
                      <div><Label>Marks</Label><Input type="number" className="w-20" value={qForm.marks} onChange={(e) => setQForm({ ...qForm, marks: Number(e.target.value) })} /></div>
                    </div>
                  </>
                )}
                {exam.kind === "psychometric_scale" && (
                  <p className="text-sm text-muted-foreground">Scale options 1–5 are automatically generated for psychometric scale questions.</p>
                )}
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setQOpen(false)}>Cancel</Button>
                <Button onClick={submitQuestion} disabled={!qForm.body || createMutation.isPending}>Add</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card><CardHeader><CardTitle>Question Pool</CardTitle></CardHeader><CardContent>
        {isLoading ? <div className="text-muted-foreground">Loading questions…</div> : (
          <ol className="space-y-3">
            {questions?.map((q, idx) => (
              <li key={q.id} className="border rounded p-3">
                <div className="flex justify-between items-start gap-3">
                  <div className="flex-1">
                    <div className="text-xs text-muted-foreground mb-1">Q{idx + 1} · {q.kind.replace(/_/g, " ")} · {q.marks} marks</div>
                    <div className="font-medium">{q.body}</div>
                    <ul className="mt-2 space-y-1 text-sm">
                      {q.options.map((o) => (
                        <li key={o.id} className={`flex items-center gap-2 ${o.isCorrect ? "text-emerald-700 font-medium" : "text-muted-foreground"}`}>
                          <span className="w-1 h-1 rounded-full bg-current inline-block" />
                          {o.body}{o.score != null && <span className="text-xs ml-1">({o.score} pts)</span>}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </li>
            ))}
            {questions?.length === 0 && <div className="text-muted-foreground">No questions yet. Add one or bulk upload.</div>}
          </ol>
        )}
      </CardContent></Card>
    </div>
  );
}
