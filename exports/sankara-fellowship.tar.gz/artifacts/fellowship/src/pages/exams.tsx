import { useState } from "react";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListExams,
  useCreateExam,
  useListPrograms,
  getListExamsQueryKey,
  getListProgramsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ArrowRight, Clock, FileText, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const KINDS = [
  { value: "mcq", label: "MCQ" },
  { value: "psychometric_mcq", label: "Psychometric (MCQ)" },
  { value: "psychometric_paired", label: "Psychometric (Paired)" },
  { value: "psychometric_scale", label: "Psychometric (Scale 1-5)" },
  { value: "psychometric_conditional", label: "Psychometric (Conditional)" },
];

export default function ExamsPage() {
  const { data: exams, isLoading } = useListExams(undefined, { query: { queryKey: getListExamsQueryKey() } });
  const { data: programs } = useListPrograms({ query: { queryKey: getListProgramsQueryKey() } });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    title: "", kind: "mcq", programId: "", durationMinutes: 60, totalQuestions: 20, passingScore: 0, description: "",
  });

  const createMutation = useCreateExam({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListExamsQueryKey() });
        setOpen(false);
        toast({ title: "Exam created" });
      },
    },
  });

  const submit = () => {
    createMutation.mutate({
      data: {
        title: form.title,
        kind: form.kind,
        programId: form.programId ? Number(form.programId) : null,
        durationMinutes: form.durationMinutes,
        totalQuestions: form.totalQuestions,
        passingScore: form.passingScore || undefined,
        description: form.description || undefined,
      },
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Exams</h1>
          <p className="text-muted-foreground">MCQ and psychometric assessments for fellowship admissions.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="bg-gradient-to-r from-orange-500 to-amber-500"><Plus className="h-4 w-4 mr-2" /> New Exam</Button></DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Create Exam</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Kind</Label>
                  <Select value={form.kind} onValueChange={(v) => setForm({ ...form, kind: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{KINDS.map((k) => <SelectItem key={k.value} value={k.value}>{k.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Program</Label>
                  <Select value={form.programId} onValueChange={(v) => setForm({ ...form, programId: v })}>
                    <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                    <SelectContent>{programs?.map((p) => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div><Label>Duration (min)</Label><Input type="number" value={form.durationMinutes} onChange={(e) => setForm({ ...form, durationMinutes: Number(e.target.value) })} /></div>
                <div><Label>Total Questions</Label><Input type="number" value={form.totalQuestions} onChange={(e) => setForm({ ...form, totalQuestions: Number(e.target.value) })} /></div>
                <div><Label>Passing Score</Label><Input type="number" value={form.passingScore} onChange={(e) => setForm({ ...form, passingScore: Number(e.target.value) })} /></div>
              </div>
              <div><Label>Description</Label><Textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={submit} disabled={!form.title || createMutation.isPending}>Create Exam</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? <div className="text-muted-foreground">Loading…</div> : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {exams?.map((e) => (
            <Link key={e.id} href={`/exams/${e.id}`}>
              <Card className="cursor-pointer hover:shadow-md transition border-l-4 border-l-orange-500">
                <CardHeader>
                  <div className="text-xs text-orange-600 font-semibold uppercase tracking-wider">{e.kind.replace(/_/g, " ")}</div>
                  <CardTitle className="text-lg">{e.title}</CardTitle>
                  {e.programName && <div className="text-xs text-muted-foreground">{e.programName}</div>}
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="grid grid-cols-3 gap-2 text-center text-sm">
                    <div><div className="font-semibold flex items-center justify-center gap-1"><Clock className="h-3 w-3" /> {e.durationMinutes}m</div></div>
                    <div><div className="font-semibold flex items-center justify-center gap-1"><FileText className="h-3 w-3" /> {e.totalQuestions} qs</div></div>
                    <div><div className="font-semibold">{e.questionCount} loaded</div></div>
                  </div>
                  <div className="text-xs text-orange-600 flex items-center gap-1 pt-2 border-t">Manage questions <ArrowRight className="h-3 w-3" /></div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
