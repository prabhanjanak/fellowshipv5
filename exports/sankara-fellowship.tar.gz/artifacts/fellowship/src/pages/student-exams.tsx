import { Link } from "wouter";
import {
  useListExams,
  useListMyAttempts,
  getListExamsQueryKey,
  getListMyAttemptsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Clock, FileText, Play } from "lucide-react";

export default function StudentExamsPage() {
  const { data: exams } = useListExams(undefined, { query: { queryKey: getListExamsQueryKey() } });
  const { data: attempts } = useListMyAttempts({ query: { queryKey: getListMyAttemptsQueryKey() } });

  const isCompleted = (examId: number) => attempts?.some((a) => a.examId === examId && a.submittedAt) ?? false;
  const isInProgress = (examId: number) => attempts?.some((a) => a.examId === examId && !a.submittedAt) ?? false;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Your Exams</h1>
        <p className="text-muted-foreground">Take available entrance and psychometric exams.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {exams?.map((e) => {
          const completed = isCompleted(e.id);
          const inProgress = isInProgress(e.id);
          return (
            <Card key={e.id} className="border-l-4 border-l-orange-500">
              <CardHeader>
                <div className="text-xs text-orange-600 font-semibold uppercase tracking-wider">{e.kind.replace(/_/g, " ")}</div>
                <CardTitle>{e.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {e.durationMinutes} min</span>
                  <span className="flex items-center gap-1"><FileText className="h-3 w-3" /> {e.totalQuestions} questions</span>
                </div>
                {completed ? (
                  <div className="text-sm text-emerald-700 font-medium">Completed</div>
                ) : inProgress ? (
                  <Link href={`/student/exam/${e.id}`}><Button className="bg-gradient-to-r from-orange-500 to-amber-500"><Play className="h-4 w-4 mr-2" /> Resume Exam</Button></Link>
                ) : (
                  <Link href={`/student/exam/${e.id}`}><Button className="bg-gradient-to-r from-orange-500 to-amber-500"><Play className="h-4 w-4 mr-2" /> Start Exam</Button></Link>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader><CardTitle>Your Attempts</CardTitle></CardHeader>
        <CardContent className="p-0">
          {!attempts || attempts.length === 0 ? <div className="p-6 text-muted-foreground">No attempts yet.</div> : (
            <Table>
              <TableHeader><TableRow><TableHead>Exam</TableHead><TableHead>Kind</TableHead><TableHead>Score</TableHead><TableHead>Submitted</TableHead></TableRow></TableHeader>
              <TableBody>{attempts.map((a) => (
                <TableRow key={a.id}>
                  <TableCell className="font-medium">{a.examTitle}</TableCell>
                  <TableCell className="text-muted-foreground">{a.examKind.replace(/_/g, " ")}</TableCell>
                  <TableCell>{a.score != null ? `${a.score.toFixed(1)} / ${a.maxScore?.toFixed(1) ?? "—"}` : "—"}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{a.submittedAt ? new Date(a.submittedAt).toLocaleString() : "In progress"}</TableCell>
                </TableRow>
              ))}</TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
