import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListMyInterviewAssignments,
  useSubmitInterviewScore,
  getListMyInterviewAssignmentsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ClipboardCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function DoctorPage() {
  const { data: assignments, isLoading } = useListMyInterviewAssignments({ query: { queryKey: getListMyInterviewAssignmentsQueryKey() } });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [target, setTarget] = useState<{ candidateId: number; candidateName: string } | null>(null);
  const [score, setScore] = useState<number>(7);
  const [remarks, setRemarks] = useState("");

  const submitMutation = useSubmitInterviewScore({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMyInterviewAssignmentsQueryKey() });
        setTarget(null); setScore(7); setRemarks("");
        toast({ title: "Score submitted" });
      },
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <div className="text-xs uppercase tracking-wider text-orange-600 font-semibold">Interview Doctor</div>
        <h1 className="text-3xl font-bold tracking-tight mt-1">Your Interview Panel</h1>
        <p className="text-muted-foreground">Score candidates after their fellowship interview.</p>
      </div>

      {isLoading ? <div className="text-muted-foreground">Loading…</div> : !assignments || assignments.length === 0 ? (
        <Card><CardContent className="p-6 text-muted-foreground">You have no interview assignments yet.</CardContent></Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {assignments.map((a) => (
            <Card key={a.id} className={`border-l-4 ${a.existingScore ? "border-l-emerald-500" : "border-l-orange-500"}`}>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">{a.candidateName}</CardTitle>
                <div className="text-xs text-muted-foreground font-mono">{a.candidateCode} · {a.unitName ?? "—"}</div>
              </CardHeader>
              <CardContent className="space-y-3">
                {a.existingScore ? (
                  <>
                    <div className="text-2xl font-bold text-emerald-700">{a.existingScore.score.toFixed(1)} / 10</div>
                    {a.existingScore.remarks && <div className="text-sm text-muted-foreground italic">"{a.existingScore.remarks}"</div>}
                    <div className="text-xs text-muted-foreground">Submitted {new Date(a.existingScore.submittedAt).toLocaleString()}</div>
                  </>
                ) : (
                  <Button size="sm" onClick={() => { setTarget({ candidateId: a.candidateId, candidateName: a.candidateName }); setScore(7); setRemarks(""); }}>
                    <ClipboardCheck className="h-4 w-4 mr-2" /> Score Interview
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!target} onOpenChange={(v) => !v && setTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Score: {target?.candidateName}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Score: <span className="text-2xl font-bold text-orange-700 ml-2">{score.toFixed(1)}</span> / 10</Label>
              <Slider min={0} max={10} step={0.5} value={[score]} onValueChange={(v) => setScore(v[0] ?? 0)} className="mt-2" />
            </div>
            <div>
              <Label>Remarks</Label>
              <Textarea rows={4} value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Clinical knowledge, communication, attitude…" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setTarget(null)}>Cancel</Button>
            <Button onClick={() => target && submitMutation.mutate({ data: { candidateId: target.candidateId, score, remarks } })} disabled={submitMutation.isPending}>Submit</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
