import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListAllocations,
  useListPrograms,
  useListSpecialities,
  useRunAllocation,
  useOverrideAllocation,
  getAllocationLetter,
  getListAllocationsQueryKey,
  getListProgramsQueryKey,
  getListSpecialitiesQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Download, Play, Pencil } from "lucide-react";
import { statusColor } from "@/lib/status";
import { useToast } from "@/hooks/use-toast";
import { downloadPdfFromBase64 } from "@/lib/status";

export default function AllocationsPage() {
  const [programId, setProgramId] = useState<string>("");
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const params = programId ? { programId: Number(programId) } : undefined;
  const { data: allocations, isLoading } = useListAllocations(params, {
    query: { queryKey: getListAllocationsQueryKey(params) },
  });
  const { data: programs } = useListPrograms({ query: { queryKey: getListProgramsQueryKey() } });
  const specParams = programId ? { programId: Number(programId) } : undefined;
  const { data: specs } = useListSpecialities(specParams, { query: { queryKey: getListSpecialitiesQueryKey(specParams) } });

  const [runOpen, setRunOpen] = useState(false);
  const [overrideTarget, setOverrideTarget] = useState<{ id: number; status: string; specialityId: number | null } | null>(null);

  const runMutation = useRunAllocation({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getListAllocationsQueryKey() });
        setRunOpen(false);
        toast({ title: "Allocation complete", description: `Selected: ${data.selected} · Waitlisted: ${data.waitlisted} · Rejected: ${data.rejected}` });
      },
    },
  });

  const overrideMutation = useOverrideAllocation({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAllocationsQueryKey() });
        setOverrideTarget(null);
        toast({ title: "Allocation updated" });
      },
    },
  });

  const downloadLetter = async (allocId: number, candName: string) => {
    try {
      const data = await getAllocationLetter(allocId);
      downloadPdfFromBase64(data.pdfBase64, `${candName.replace(/\s+/g, "_")}_letter.pdf`);
    } catch (e) {
      toast({ variant: "destructive", title: "Download failed", description: (e as Error).message });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Seat Allocations</h1>
          <p className="text-muted-foreground">Run, review, and override fellowship seat allocations.</p>
        </div>
        <Button className="bg-gradient-to-r from-orange-500 to-amber-500" onClick={() => setRunOpen(true)} disabled={!programId}>
          <Play className="h-4 w-4 mr-2" /> Run Allocation
        </Button>
      </div>

      <Card>
        <CardHeader>
          <Select value={programId} onValueChange={setProgramId}>
            <SelectTrigger className="w-[400px]"><SelectValue placeholder="Select a program" /></SelectTrigger>
            <SelectContent>{programs?.map((p) => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}</SelectContent>
          </Select>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? <div className="p-6 text-muted-foreground">Loading…</div> : !allocations || allocations.length === 0 ? (
            <div className="p-6 text-muted-foreground">No allocations to display. Run allocation for the selected program.</div>
          ) : (
            <Table>
              <TableHeader><TableRow>
                <TableHead className="w-[60px]">Rank</TableHead>
                <TableHead>Candidate</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Speciality</TableHead>
                <TableHead>Unit</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow></TableHeader>
              <TableBody>{allocations.map((a) => (
                <TableRow key={a.id}>
                  <TableCell className="font-semibold">{a.rank ?? "—"}</TableCell>
                  <TableCell className="font-medium">{a.candidateName}</TableCell>
                  <TableCell className="font-mono text-xs">{a.candidateCode}</TableCell>
                  <TableCell>{a.specialityName ?? <span className="text-muted-foreground">—</span>}</TableCell>
                  <TableCell>{a.unitName ?? <span className="text-muted-foreground">—</span>}</TableCell>
                  <TableCell><span className={`inline-flex px-2 py-0.5 rounded-full text-xs border ${statusColor(a.status)}`}>{a.status}</span></TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" onClick={() => setOverrideTarget({ id: a.id, status: a.status, specialityId: a.specialityId ?? null })}><Pencil className="h-3 w-3 mr-1" /> Override</Button>
                    <Button variant="ghost" size="sm" onClick={() => downloadLetter(a.id, a.candidateName)}><Download className="h-3 w-3 mr-1" /> Letter</Button>
                  </TableCell>
                </TableRow>
              ))}</TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={runOpen} onOpenChange={setRunOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Run allocation for this program?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will rank all candidates by total score and assign them to their highest-available preference. Existing allocations for this program will be replaced.</p>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setRunOpen(false)}>Cancel</Button>
            <Button onClick={() => programId && runMutation.mutate({ data: { programId: Number(programId) } })} disabled={runMutation.isPending}>Run</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!overrideTarget} onOpenChange={(v) => !v && setOverrideTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Override Allocation</DialogTitle></DialogHeader>
          {overrideTarget && (
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium">Status</label>
                <Select value={overrideTarget.status} onValueChange={(v) => setOverrideTarget({ ...overrideTarget, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SELECTED">SELECTED</SelectItem>
                    <SelectItem value="WAITLISTED">WAITLISTED</SelectItem>
                    <SelectItem value="REJECTED">REJECTED</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Speciality (optional)</label>
                <Select value={overrideTarget.specialityId != null ? String(overrideTarget.specialityId) : "none"} onValueChange={(v) => setOverrideTarget({ ...overrideTarget, specialityId: v === "none" ? null : Number(v) })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— None —</SelectItem>
                    {specs?.map((s) => <SelectItem key={s.id} value={String(s.id)}>{s.name} ({s.filledSeats}/{s.seats})</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOverrideTarget(null)}>Cancel</Button>
            <Button onClick={() => overrideTarget && overrideMutation.mutate({ allocationId: overrideTarget.id, data: { status: overrideTarget.status, specialityId: overrideTarget.specialityId } })} disabled={overrideMutation.isPending}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
