import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListSpecialities,
  useListPrograms,
  useListMyPreferences,
  useSetMyPreferences,
  getListSpecialitiesQueryKey,
  getListProgramsQueryKey,
  getListMyPreferencesQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowDown, ArrowUp, ListOrdered, Plus, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function StudentPreferencesPage() {
  const { data: specs } = useListSpecialities(undefined, { query: { queryKey: getListSpecialitiesQueryKey() } });
  const { data: programs } = useListPrograms({ query: { queryKey: getListProgramsQueryKey() } });
  const { data: existing } = useListMyPreferences({ query: { queryKey: getListMyPreferencesQueryKey() } });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [order, setOrder] = useState<number[]>([]);

  useEffect(() => {
    if (existing && order.length === 0) setOrder(existing.map((p) => p.specialityId));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [existing]);

  const saveMutation = useSetMyPreferences({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMyPreferencesQueryKey() });
        queryClient.invalidateQueries({ queryKey: ["/candidates/me"] });
        toast({ title: "Preferences saved" });
      },
    },
  });

  const move = (idx: number, dir: number) => {
    const next = [...order];
    const j = idx + dir;
    if (j < 0 || j >= next.length) return;
    [next[idx], next[j]] = [next[j]!, next[idx]!];
    setOrder(next);
  };
  const add = (id: number) => { if (!order.includes(id)) setOrder([...order, id]); };
  const remove = (id: number) => setOrder(order.filter((x) => x !== id));

  const programGroups = programs?.map((p) => ({
    program: p,
    specs: specs?.filter((s) => s.programId === p.id) ?? [],
  })) ?? [];

  const orderedSpecs = order.map((id) => specs?.find((s) => s.id === id)).filter(Boolean);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Your Preferences</h1>
        <p className="text-muted-foreground">Pick specialities and arrange them in order of preference. Top choice first.</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Available Specialities</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {programGroups.map(({ program, specs }) => (
              <div key={program.id}>
                <div className="text-xs uppercase tracking-wider font-semibold text-orange-600 mb-2">{program.name}</div>
                <div className="space-y-1">
                  {specs.map((s) => (
                    <div key={s.id} className="flex items-center justify-between p-2 border rounded">
                      <div>
                        <div className="font-medium text-sm">{s.name}</div>
                        <div className="text-xs text-muted-foreground">{s.seats} seats</div>
                      </div>
                      <Button size="sm" variant="outline" disabled={order.includes(s.id)} onClick={() => add(s.id)}>
                        <Plus className="h-3 w-3 mr-1" />
                        {order.includes(s.id) ? "Added" : "Add"}
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2"><ListOrdered className="h-4 w-4 text-orange-500" /> Your ranked choices</CardTitle>
            <Button onClick={() => saveMutation.mutate({ data: { specialityIds: order } })} disabled={saveMutation.isPending} className="bg-gradient-to-r from-orange-500 to-amber-500">Save</Button>
          </CardHeader>
          <CardContent>
            {orderedSpecs.length === 0 ? (
              <div className="text-muted-foreground text-sm">Add specialities from the left to build your preference list.</div>
            ) : (
              <ol className="space-y-2">
                {orderedSpecs.map((s, idx) => s && (
                  <li key={s.id} className="flex items-center gap-2 p-2 border rounded bg-orange-50/40">
                    <span className="w-7 h-7 rounded-full bg-orange-500 text-white text-sm font-bold flex items-center justify-center">{idx + 1}</span>
                    <div className="flex-1">
                      <div className="font-medium text-sm">{s.name}</div>
                      <div className="text-xs text-muted-foreground">{programs?.find((p) => p.id === s.programId)?.name}</div>
                    </div>
                    <Button size="sm" variant="ghost" disabled={idx === 0} onClick={() => move(idx, -1)}><ArrowUp className="h-3 w-3" /></Button>
                    <Button size="sm" variant="ghost" disabled={idx === orderedSpecs.length - 1} onClick={() => move(idx, 1)}><ArrowDown className="h-3 w-3" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => remove(s.id)}><X className="h-3 w-3" /></Button>
                  </li>
                ))}
              </ol>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
