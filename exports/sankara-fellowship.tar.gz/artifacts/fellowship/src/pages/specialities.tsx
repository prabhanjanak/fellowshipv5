import { useState } from "react";
import {
  useListSpecialities,
  useListPrograms,
  getListSpecialitiesQueryKey,
  getListProgramsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";

export default function SpecialitiesPage() {
  const [programId, setProgramId] = useState<string>("all");
  const params = programId === "all" ? undefined : { programId: Number(programId) };
  const { data: specs, isLoading } = useListSpecialities(params, {
    query: { queryKey: getListSpecialitiesQueryKey(params) },
  });
  const { data: programs } = useListPrograms({ query: { queryKey: getListProgramsQueryKey() } });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">All Specialities</h1>
        <p className="text-muted-foreground">Cross-program speciality view with seat utilization.</p>
      </div>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Specialities</CardTitle>
          <Select value={programId} onValueChange={setProgramId}>
            <SelectTrigger className="w-[280px]"><SelectValue placeholder="Filter by program" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All programs</SelectItem>
              {programs?.map((p) => (
                <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent>
          {isLoading ? <div className="text-muted-foreground">Loading…</div> : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Speciality</TableHead>
                  <TableHead>Code</TableHead>
                  <TableHead>Seats</TableHead>
                  <TableHead>Filled</TableHead>
                  <TableHead className="w-[240px]">Utilization</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {specs?.map((s) => {
                  const pct = s.seats > 0 ? Math.round((s.filledSeats / s.seats) * 100) : 0;
                  return (
                    <TableRow key={s.id}>
                      <TableCell className="font-medium">{s.name}</TableCell>
                      <TableCell className="font-mono text-xs">{s.code}</TableCell>
                      <TableCell>{s.seats}</TableCell>
                      <TableCell>{s.filledSeats}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={pct} className="h-2 flex-1" />
                          <span className="text-xs text-muted-foreground tabular-nums w-10">{pct}%</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
