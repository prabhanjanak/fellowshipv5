import {
  useGetMyAllocation,
  getMyAllocation,
  getAllocationLetter,
  getGetMyAllocationQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, GraduationCap, MapPin } from "lucide-react";
import { statusColor } from "@/lib/status";
import { downloadPdfFromBase64 } from "@/lib/status";
import { useToast } from "@/hooks/use-toast";

export default function StudentAllocationPage() {
  const { data: alloc, isLoading, error } = useGetMyAllocation({ query: { queryKey: getGetMyAllocationQueryKey(), retry: false } });
  const { toast } = useToast();

  void getMyAllocation;

  const downloadLetter = async () => {
    if (!alloc) return;
    try {
      const data = await getAllocationLetter(alloc.id);
      downloadPdfFromBase64(data.pdfBase64, "allocation_letter.pdf");
    } catch (e) {
      toast({ variant: "destructive", title: "Download failed", description: (e as Error).message });
    }
  };

  if (isLoading) return <div>Loading…</div>;

  if (error || !alloc) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold tracking-tight">Allocation</h1>
        <Card><CardContent className="p-8 text-center text-muted-foreground">
          <GraduationCap className="h-12 w-12 mx-auto mb-3 text-muted-foreground/50" />
          Your allocation has not been published yet. Please check back after the allocation has been run.
        </CardContent></Card>
      </div>
    );
  }

  const statusUpper = alloc.status;
  const isSelected = statusUpper === "SELECTED";
  const isWaitlisted = statusUpper === "WAITLISTED";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Your Allocation</h1>
        <p className="text-muted-foreground">Outcome of your fellowship application.</p>
      </div>

      <Card className={`border-2 ${isSelected ? "border-emerald-300 bg-emerald-50/50" : isWaitlisted ? "border-amber-300 bg-amber-50/50" : "border-rose-300 bg-rose-50/50"}`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl">{alloc.programName}</CardTitle>
            <span className={`inline-flex px-3 py-1 rounded-full text-sm font-semibold border ${statusColor(statusUpper)}`}>{statusUpper}</span>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {isSelected && alloc.specialityName && (
            <div className="grid grid-cols-2 gap-4">
              <div><div className="text-xs text-muted-foreground">Speciality</div><div className="font-bold text-lg">{alloc.specialityName}</div></div>
              <div><div className="text-xs text-muted-foreground">Posting Unit</div><div className="font-bold text-lg flex items-center gap-1"><MapPin className="h-4 w-4 text-orange-500" /> {alloc.unitName ?? "—"}</div></div>
              <div><div className="text-xs text-muted-foreground">Rank</div><div className="font-bold text-lg">#{alloc.rank}</div></div>
              <div><div className="text-xs text-muted-foreground">Allocated on</div><div className="font-bold text-lg">{new Date(alloc.allocatedAt).toLocaleDateString()}</div></div>
            </div>
          )}
          {isWaitlisted && (
            <div className="text-amber-800">
              You are currently on the waitlist at rank <span className="font-bold">#{alloc.rank}</span>. We will notify you if a seat becomes available.
            </div>
          )}
          {!isSelected && !isWaitlisted && (
            <div className="text-rose-800">Unfortunately, no seat could be allocated this admission cycle.</div>
          )}
          <Button onClick={downloadLetter} className="bg-gradient-to-r from-orange-500 to-amber-500">
            <Download className="h-4 w-4 mr-2" /> Download Allocation Letter
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
