import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetProgram,
  useCreateSpeciality,
  useUpdateSpeciality,
  getGetProgramQueryKey,
  getListProgramsQueryKey,
  getListSpecialitiesQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ChevronLeft, Plus, Pencil } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ProgramDetailPage() {
  const [, params] = useRoute<{ id: string }>("/programs/:id");
  const id = Number(params?.id);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [createOpen, setCreateOpen] = useState(false);
  const [createForm, setCreateForm] = useState({ name: "", code: "", seats: 4 });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState({ name: "", seats: 0 });

  const { data: program, isLoading } = useGetProgram(id, {
    query: { enabled: !!id, queryKey: getGetProgramQueryKey(id) },
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: getGetProgramQueryKey(id) });
    queryClient.invalidateQueries({ queryKey: getListProgramsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListSpecialitiesQueryKey() });
  };

  const createMutation = useCreateSpeciality({
    mutation: {
      onSuccess: () => {
        invalidate();
        setCreateOpen(false);
        setCreateForm({ name: "", code: "", seats: 4 });
        toast({ title: "Speciality created" });
      },
    },
  });

  const updateMutation = useUpdateSpeciality({
    mutation: {
      onSuccess: () => {
        invalidate();
        setEditingId(null);
        toast({ title: "Speciality updated" });
      },
    },
  });

  if (isLoading) return <div>Loading program…</div>;
  if (!program) return <div>Program not found.</div>;

  return (
    <div className="space-y-6">
      <Link href="/programs">
        <Button variant="ghost" size="sm" className="-ml-2"><ChevronLeft className="h-4 w-4 mr-1" /> All programs</Button>
      </Link>
      <div className="flex items-end justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground font-mono">{program.code} · {program.academicYear}</div>
          <h1 className="text-3xl font-bold tracking-tight mt-1">{program.name}</h1>
          <p className="text-muted-foreground max-w-2xl mt-2">{program.description}</p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold text-orange-600">{program.totalSeats}</div>
          <div className="text-xs text-muted-foreground">Total seats across {program.specialityCount} specialities</div>
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Specialities</CardTitle>
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button size="sm"><Plus className="h-4 w-4 mr-1" /> Add Speciality</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Add Speciality</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Name</Label><Input value={createForm.name} onChange={(e) => setCreateForm({ ...createForm, name: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Code</Label><Input value={createForm.code} onChange={(e) => setCreateForm({ ...createForm, code: e.target.value })} /></div>
                  <div><Label>Seats</Label><Input type="number" value={createForm.seats} onChange={(e) => setCreateForm({ ...createForm, seats: Number(e.target.value) })} /></div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setCreateOpen(false)}>Cancel</Button>
                <Button onClick={() => createMutation.mutate({ data: { programId: id, ...createForm } })} disabled={createMutation.isPending}>Create</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Seats</TableHead>
                <TableHead>Filled</TableHead>
                <TableHead className="w-[200px]">Fill rate</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {program.specialities?.map((s) => {
                const isEditing = editingId === s.id;
                const fillPct = s.seats > 0 ? Math.round((s.filledSeats / s.seats) * 100) : 0;
                return (
                  <TableRow key={s.id}>
                    <TableCell>
                      {isEditing ? (
                        <Input value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} />
                      ) : (
                        <span className="font-medium">{s.name}</span>
                      )}
                    </TableCell>
                    <TableCell className="font-mono text-xs">{s.code}</TableCell>
                    <TableCell>
                      {isEditing ? (
                        <Input type="number" className="w-20" value={editForm.seats} onChange={(e) => setEditForm({ ...editForm, seats: Number(e.target.value) })} />
                      ) : s.seats}
                    </TableCell>
                    <TableCell>{s.filledSeats}</TableCell>
                    <TableCell><Progress value={fillPct} className="h-2" /></TableCell>
                    <TableCell>
                      {isEditing ? (
                        <div className="flex gap-1">
                          <Button size="sm" onClick={() => updateMutation.mutate({ specialityId: s.id, data: editForm })}>Save</Button>
                          <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>X</Button>
                        </div>
                      ) : (
                        <Button size="sm" variant="ghost" onClick={() => { setEditingId(s.id); setEditForm({ name: s.name, seats: s.seats }); }}>
                          <Pencil className="h-3 w-3" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
