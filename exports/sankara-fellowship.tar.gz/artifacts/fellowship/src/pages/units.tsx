import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListUnits,
  useCreateUnit,
  getListUnitsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { MapPin, Plus, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function UnitsPage() {
  const { data: units, isLoading } = useListUnits({ query: { queryKey: getListUnitsQueryKey() } });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", city: "", state: "" });

  const createMutation = useCreateUnit({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListUnitsQueryKey() });
        setOpen(false);
        setForm({ name: "", city: "", state: "" });
        toast({ title: "Unit added" });
      },
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Hospital Units</h1>
          <p className="text-muted-foreground">Sankara Eye Foundation centres and posting locations.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-orange-500 to-amber-500"><Plus className="h-4 w-4 mr-2" /> New Unit</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Add Unit</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Unit Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>City</Label><Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
                <div><Label>State</Label><Input value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} /></div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={() => createMutation.mutate({ data: form })} disabled={createMutation.isPending || !form.name}>Create</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? <div className="text-muted-foreground">Loading…</div> : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {units?.map((u) => (
            <Card key={u.id} className="border-l-4 border-l-orange-500">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2"><MapPin className="h-4 w-4 text-orange-500" /> {u.name}</CardTitle>
                <div className="text-sm text-muted-foreground">{u.city}, {u.state}</div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span className="font-semibold">{u.candidateCount}</span>
                  <span className="text-muted-foreground">candidates assigned</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
