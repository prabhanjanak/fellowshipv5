import { createContext, useContext, ReactNode, useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useGetMe, CurrentUser, getGetMeQueryKey } from "@workspace/api-client-react";

interface AuthContextType {
  user: CurrentUser | null;
  isLoading: boolean;
  login: (token: string) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(localStorage.getItem("fellowship_token"));
  const [, setLocation] = useLocation();

  const { data: user, isLoading: isUserLoading, error } = useGetMe({
    query: {
      enabled: !!token,
      retry: false,
      queryKey: getGetMeQueryKey(),
    },
  });

  const isLoading = !!token && isUserLoading;

  useEffect(() => {
    if (error) {
      localStorage.removeItem("fellowship_token");
      setToken(null);
    }
  }, [error]);

  const login = (newToken: string) => {
    localStorage.setItem("fellowship_token", newToken);
    setToken(newToken);
  };

  const logout = () => {
    localStorage.removeItem("fellowship_token");
    setToken(null);
    setLocation("/login");
  };

  return (
    <AuthContext.Provider
      value={{
        user: user || null,
        isLoading,
        login,
        logout,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
