export function statusColor(status: string): string {
  switch (status) {
    case "SELECTED":
    case "allocated":
      return "bg-emerald-100 text-emerald-800 border-emerald-200";
    case "WAITLISTED":
    case "waitlisted":
      return "bg-amber-100 text-amber-800 border-amber-200";
    case "REJECTED":
    case "rejected":
      return "bg-rose-100 text-rose-800 border-rose-200";
    case "interview_completed":
    case "exam_completed":
      return "bg-sky-100 text-sky-800 border-sky-200";
    case "interview_pending":
    case "exam_pending":
      return "bg-violet-100 text-violet-800 border-violet-200";
    case "documents_pending":
      return "bg-orange-100 text-orange-800 border-orange-200";
    case "registered":
    default:
      return "bg-slate-100 text-slate-700 border-slate-200";
  }
}

export function statusLabel(status: string): string {
  return status.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

export function downloadPdfFromBase64(base64: string, fileName = "letter.pdf") {
  const bin = atob(base64);
  const arr = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  const blob = new Blob([arr], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function openPdfFromBase64(base64: string) {
  const bin = atob(base64);
  const arr = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  const blob = new Blob([arr], { type: "application/pdf" });
  window.open(URL.createObjectURL(blob), "_blank");
}
