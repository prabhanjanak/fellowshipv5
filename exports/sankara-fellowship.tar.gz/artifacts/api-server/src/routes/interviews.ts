import { Router } from "express";
import { and, eq } from "drizzle-orm";
import { db, doctorAssignmentsTable, interviewScoresTable, candidatesTable, unitsTable, usersTable } from "@workspace/db";
import { requireAuth, requireRole } from "../middleware/auth";

const router: Router = Router();

router.get("/interviews/assignments", requireAuth, requireRole("doctor"), async (req, res) => {
  const userId = req.user!.userId;
  const assigns = await db.select().from(doctorAssignmentsTable).where(eq(doctorAssignmentsTable.doctorId, userId));
  const candidates = await db.select().from(candidatesTable);
  const units = await db.select().from(unitsTable);
  const scores = await db.select().from(interviewScoresTable).where(eq(interviewScoresTable.doctorId, userId));
  const users = await db.select().from(usersTable);
  res.json(assigns.map((a) => {
    const c = candidates.find((x) => x.id === a.candidateId);
    const unit = c?.unitId ? units.find((u) => u.id === c.unitId) : null;
    const sc = scores.find((s) => s.candidateId === a.candidateId);
    const docUser = users.find((u) => u.id === userId);
    return {
      id: a.id,
      candidateId: a.candidateId,
      candidateName: c?.fullName ?? "",
      candidateCode: c?.candidateCode ?? "",
      unitName: unit?.name ?? null,
      scheduledAt: a.scheduledAt?.toISOString() ?? null,
      status: sc ? "completed" : a.status,
      existingScore: sc ? {
        id: sc.id,
        candidateId: sc.candidateId,
        doctorId: sc.doctorId,
        doctorName: docUser?.fullName ?? "",
        score: sc.score,
        remarks: sc.remarks,
        submittedAt: sc.submittedAt.toISOString(),
      } : null,
    };
  }));
});

router.post("/interviews/scores", requireAuth, requireRole("doctor"), async (req, res) => {
  const userId = req.user!.userId;
  const { candidateId, score, remarks } = req.body as { candidateId: number; score: number; remarks?: string };
  if (!candidateId || score == null) { res.status(400).json({ error: "Missing fields" }); return; }
  const existing = await db.select().from(interviewScoresTable).where(
    and(eq(interviewScoresTable.candidateId, candidateId), eq(interviewScoresTable.doctorId, userId)),
  );
  let row;
  if (existing.length > 0) {
    [row] = await db.update(interviewScoresTable).set({
      score,
      remarks: remarks ?? null,
      submittedAt: new Date(),
    }).where(eq(interviewScoresTable.id, existing[0]!.id)).returning();
  } else {
    [row] = await db.insert(interviewScoresTable).values({
      candidateId,
      doctorId: userId,
      score,
      remarks: remarks ?? null,
    }).returning();
  }
  if (!row) { res.status(500).json({ error: "Failed" }); return; }

  // Update candidate status
  const [u] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  const allScores = await db.select().from(interviewScoresTable).where(eq(interviewScoresTable.candidateId, candidateId));
  if (allScores.length > 0) {
    await db.update(candidatesTable).set({ status: "interview_completed" }).where(eq(candidatesTable.id, candidateId));
  }
  // mark assignment done
  await db.update(doctorAssignmentsTable).set({ status: "completed" })
    .where(and(eq(doctorAssignmentsTable.doctorId, userId), eq(doctorAssignmentsTable.candidateId, candidateId)));

  res.json({
    id: row.id,
    candidateId: row.candidateId,
    doctorId: row.doctorId,
    doctorName: u?.fullName ?? "",
    score: row.score,
    remarks: row.remarks,
    submittedAt: row.submittedAt.toISOString(),
  });
});

export default router;
