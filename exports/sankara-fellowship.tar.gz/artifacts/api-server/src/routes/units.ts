import { Router } from "express";
import { db, unitsTable, candidatesTable } from "@workspace/db";
import { requireAuth, requireRole } from "../middleware/auth";

const router: Router = Router();

router.get("/units", requireAuth, async (_req, res) => {
  const units = await db.select().from(unitsTable);
  const candidates = await db.select().from(candidatesTable);
  const counts = new Map<number, number>();
  for (const c of candidates) {
    if (c.unitId != null) counts.set(c.unitId, (counts.get(c.unitId) ?? 0) + 1);
  }
  res.json(units.map((u) => ({
    id: u.id,
    name: u.name,
    city: u.city,
    state: u.state,
    candidateCount: counts.get(u.id) ?? 0,
  })));
});

router.post("/units", requireAuth, requireRole("super_admin", "program_admin"), async (req, res) => {
  const { name, city, state } = req.body as { name: string; city: string; state: string };
  if (!name || !city || !state) { res.status(400).json({ error: "Missing fields" }); return; }
  const [u] = await db.insert(unitsTable).values({ name, city, state }).returning();
  if (!u) { res.status(500).json({ error: "Failed" }); return; }
  res.json({ id: u.id, name: u.name, city: u.city, state: u.state, candidateCount: 0 });
});

export default router;
