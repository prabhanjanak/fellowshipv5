import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, unitsTable, programsTable } from "@workspace/db";
import { hashPassword } from "../lib/auth";
import { requireAuth, requireRole } from "../middleware/auth";

const router: Router = Router();

router.get("/users", requireAuth, requireRole("super_admin", "program_admin"), async (req, res) => {
  const role = (req.query["role"] as string | undefined) ?? undefined;
  const all = await db.select().from(usersTable);
  const filtered = role ? all.filter((u) => u.role === role) : all;
  const units = await db.select().from(unitsTable);
  const progs = await db.select().from(programsTable);
  const out = filtered.map((u) => {
    const unit = u.unitId ? units.find((x) => x.id === u.unitId) : null;
    const prog = u.programId ? progs.find((x) => x.id === u.programId) : null;
    return {
      id: u.id,
      email: u.email,
      fullName: u.fullName,
      role: u.role,
      unitId: u.unitId,
      unitName: unit?.name ?? null,
      programId: u.programId,
      programName: prog?.name ?? null,
      active: u.active,
      createdAt: u.createdAt.toISOString(),
    };
  });
  res.json(out);
});

router.post("/users", requireAuth, requireRole("super_admin"), async (req, res) => {
  const { email, fullName, password, role, unitId, programId } = req.body as {
    email: string;
    fullName: string;
    password: string;
    role: string;
    unitId?: number | null;
    programId?: number | null;
  };
  if (!email || !fullName || !password || !role) {
    res.status(400).json({ error: "Missing fields" });
    return;
  }
  const lowered = email.toLowerCase();
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, lowered));
  if (existing.length > 0) {
    res.status(409).json({ error: "Email already exists" });
    return;
  }
  const passwordHash = await hashPassword(password);
  const [user] = await db.insert(usersTable).values({
    email: lowered,
    fullName,
    passwordHash,
    role,
    unitId: unitId ?? null,
    programId: programId ?? null,
  }).returning();
  if (!user) {
    res.status(500).json({ error: "Failed to create" });
    return;
  }
  res.json({
    id: user.id,
    email: user.email,
    fullName: user.fullName,
    role: user.role,
    unitId: user.unitId,
    unitName: null,
    programId: user.programId,
    programName: null,
    active: user.active,
    createdAt: user.createdAt.toISOString(),
  });
});

export default router;
