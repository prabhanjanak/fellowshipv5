import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, candidatesTable } from "@workspace/db";
import { signToken, hashPassword, comparePassword } from "../lib/auth";
import { requireAuth } from "../middleware/auth";

const router: Router = Router();

router.post("/auth/login", async (req, res) => {
  const { email, password } = req.body as { email?: string; password?: string };
  if (!email || !password) {
    res.status(400).json({ error: "email and password required" });
    return;
  }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email.toLowerCase()));
  if (!user || !user.active) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  const ok = await comparePassword(password, user.passwordHash);
  if (!ok) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  const token = signToken({ userId: user.id, email: user.email, role: user.role });
  let candidateId: number | null = null;
  if (user.role === "student") {
    const [cand] = await db.select().from(candidatesTable).where(eq(candidatesTable.userId, user.id));
    candidateId = cand?.id ?? null;
  }
  res.json({
    token,
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
      candidateId,
      unitId: user.unitId,
      programId: user.programId,
    },
  });
});

function nextCandidateCode(seq: number): string {
  const year = new Date().getFullYear();
  return `SEH-${year}-${String(seq).padStart(4, "0")}`;
}

router.post("/auth/register-student", async (req, res) => {
  const { fullName, email, phone, password } = req.body as {
    fullName?: string;
    email?: string;
    phone?: string;
    password?: string;
  };
  if (!fullName || !email || !phone || !password) {
    res.status(400).json({ error: "All fields required" });
    return;
  }
  const lowered = email.toLowerCase();
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, lowered));
  if (existing.length > 0) {
    res.status(409).json({ error: "Email already registered" });
    return;
  }
  const passwordHash = await hashPassword(password);
  const [user] = await db.insert(usersTable).values({
    email: lowered,
    passwordHash,
    fullName,
    role: "student",
  }).returning();
  if (!user) {
    res.status(500).json({ error: "Failed to create user" });
    return;
  }
  const countResult = await db.select().from(candidatesTable);
  const code = nextCandidateCode(countResult.length + 1);
  const [cand] = await db.insert(candidatesTable).values({
    userId: user.id,
    candidateCode: code,
    fullName,
    email: lowered,
    phone,
    status: "registered",
  }).returning();
  const token = signToken({ userId: user.id, email: user.email, role: user.role });
  res.json({
    token,
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
      candidateId: cand?.id ?? null,
      unitId: null,
      programId: null,
    },
  });
});

router.get("/auth/me", requireAuth, async (req, res) => {
  const userId = req.user!.userId;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  let candidateId: number | null = null;
  if (user.role === "student") {
    const [cand] = await db.select().from(candidatesTable).where(eq(candidatesTable.userId, user.id));
    candidateId = cand?.id ?? null;
  }
  res.json({
    id: user.id,
    email: user.email,
    fullName: user.fullName,
    role: user.role,
    candidateId,
    unitId: user.unitId,
    programId: user.programId,
  });
});

export default router;
