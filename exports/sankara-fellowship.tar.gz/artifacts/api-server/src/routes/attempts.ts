import { Router } from "express";
import { and, eq } from "drizzle-orm";
import {
  db,
  candidatesTable,
  examsTable,
  questionsTable,
  optionsTable,
  examAttemptsTable,
  attemptAnswersTable,
} from "@workspace/db";
import { requireAuth, requireRole } from "../middleware/auth";

const router: Router = Router();

async function buildAttemptInProgress(attemptId: number) {
  const [a] = await db.select().from(examAttemptsTable).where(eq(examAttemptsTable.id, attemptId));
  if (!a) return null;
  const [exam] = await db.select().from(examsTable).where(eq(examsTable.id, a.examId));
  if (!exam) return null;
  const ids = (a.questionIds as number[]) ?? [];
  const qs = await db.select().from(questionsTable).where(eq(questionsTable.examId, a.examId));
  const orderedQs = ids.map((qid) => qs.find((q) => q.id === qid)).filter((q): q is typeof qs[number] => Boolean(q));
  const opts = await db.select().from(optionsTable);
  const answers = await db.select().from(attemptAnswersTable).where(eq(attemptAnswersTable.attemptId, attemptId));
  return {
    id: a.id,
    examId: a.examId,
    examTitle: exam.title,
    examKind: exam.kind,
    durationMinutes: exam.durationMinutes,
    startedAt: a.startedAt.toISOString(),
    deadline: a.deadline.toISOString(),
    submittedAt: a.submittedAt?.toISOString() ?? null,
    questions: orderedQs.map((q) => ({
      id: q.id,
      kind: q.kind,
      body: q.body,
      marks: q.marks,
      pairId: q.pairId,
      options: opts.filter((o) => o.questionId === q.id).sort((x, y) => x.position - y.position).map((o) => ({
        id: o.id,
        body: o.body,
      })),
    })),
    savedAnswers: answers.map((ans) => ({
      questionId: ans.questionId,
      optionId: ans.optionId,
      numericValue: ans.numericValue,
    })),
  };
}

router.post("/attempts/start", requireAuth, requireRole("student"), async (req, res) => {
  const { examId } = req.body as { examId: number };
  const [c] = await db.select().from(candidatesTable).where(eq(candidatesTable.userId, req.user!.userId));
  if (!c) { res.status(404).json({ error: "Candidate not found" }); return; }
  const [exam] = await db.select().from(examsTable).where(eq(examsTable.id, examId));
  if (!exam) { res.status(404).json({ error: "Exam not found" }); return; }

  const existing = await db.select().from(examAttemptsTable).where(
    and(eq(examAttemptsTable.candidateId, c.id), eq(examAttemptsTable.examId, examId)),
  );
  const live = existing.find((x) => x.submittedAt == null);
  if (live) {
    const out = await buildAttemptInProgress(live.id);
    res.json(out);
    return;
  }
  const submitted = existing.find((x) => x.submittedAt != null);
  if (submitted) {
    res.status(409).json({ error: "Already submitted this exam" });
    return;
  }

  const allQs = await db.select().from(questionsTable).where(eq(questionsTable.examId, examId));
  const shuffled = [...allQs].sort(() => Math.random() - 0.5);
  const picked = shuffled.slice(0, Math.min(exam.totalQuestions, shuffled.length));
  const deadline = new Date(Date.now() + exam.durationMinutes * 60 * 1000);

  const [att] = await db.insert(examAttemptsTable).values({
    candidateId: c.id,
    examId,
    questionIds: picked.map((q) => q.id),
    deadline,
  }).returning();
  if (!att) { res.status(500).json({ error: "Failed" }); return; }

  await db.update(candidatesTable).set({ status: "exam_pending" }).where(eq(candidatesTable.id, c.id));
  const out = await buildAttemptInProgress(att.id);
  res.json(out);
});

router.get("/attempts/:attemptId", requireAuth, async (req, res) => {
  const id = Number(req.params["attemptId"]);
  const out = await buildAttemptInProgress(id);
  if (!out) { res.status(404).json({ error: "Not found" }); return; }
  res.json(out);
});

router.post("/attempts/:attemptId/answer", requireAuth, requireRole("student"), async (req, res) => {
  const attemptId = Number(req.params["attemptId"]);
  const { questionId, optionId, numericValue } = req.body as {
    questionId: number;
    optionId?: number | null;
    numericValue?: number | null;
  };
  const existing = await db.select().from(attemptAnswersTable).where(
    and(eq(attemptAnswersTable.attemptId, attemptId), eq(attemptAnswersTable.questionId, questionId)),
  );
  if (existing.length > 0) {
    await db.update(attemptAnswersTable)
      .set({ optionId: optionId ?? null, numericValue: numericValue ?? null })
      .where(eq(attemptAnswersTable.id, existing[0]!.id));
  } else {
    await db.insert(attemptAnswersTable).values({
      attemptId,
      questionId,
      optionId: optionId ?? null,
      numericValue: numericValue ?? null,
    });
  }
  res.json({ ok: true });
});

router.post("/attempts/:attemptId/submit", requireAuth, requireRole("student"), async (req, res) => {
  const attemptId = Number(req.params["attemptId"]);
  const [att] = await db.select().from(examAttemptsTable).where(eq(examAttemptsTable.id, attemptId));
  if (!att) { res.status(404).json({ error: "Not found" }); return; }
  if (att.submittedAt) {
    res.json({
      id: att.id,
      examId: att.examId,
      score: att.score ?? 0,
      maxScore: att.maxScore ?? 0,
      submittedAt: att.submittedAt.toISOString(),
    });
    return;
  }

  const [exam] = await db.select().from(examsTable).where(eq(examsTable.id, att.examId));
  if (!exam) { res.status(404).json({ error: "Exam not found" }); return; }
  const ids = (att.questionIds as number[]) ?? [];
  const qs = await db.select().from(questionsTable).where(eq(questionsTable.examId, att.examId));
  const opts = await db.select().from(optionsTable);
  const answers = await db.select().from(attemptAnswersTable).where(eq(attemptAnswersTable.attemptId, attemptId));

  let score = 0;
  let maxScore = 0;
  for (const qid of ids) {
    const q = qs.find((x) => x.id === qid);
    if (!q) continue;
    maxScore += q.marks;
    const ans = answers.find((a) => a.questionId === qid);
    if (!ans) continue;
    if (q.kind === "mcq" || q.kind === "psychometric_mcq") {
      if (ans.optionId != null) {
        const opt = opts.find((o) => o.id === ans.optionId);
        if (opt?.isCorrect) score += q.marks;
        else if (opt?.score != null) score += opt.score;
      }
    } else if (q.kind === "psychometric_scale") {
      if (ans.numericValue != null) score += ans.numericValue;
    } else if (q.kind === "psychometric_paired" || q.kind === "psychometric_conditional") {
      if (ans.optionId != null) {
        const opt = opts.find((o) => o.id === ans.optionId);
        if (opt?.score != null) score += opt.score;
      }
    }
  }

  const submittedAt = new Date();
  await db.update(examAttemptsTable).set({
    submittedAt,
    score,
    maxScore,
  }).where(eq(examAttemptsTable.id, attemptId));

  // Update candidate status
  const [c] = await db.select().from(candidatesTable).where(eq(candidatesTable.id, att.candidateId));
  if (c) {
    const allAttempts = await db.select().from(examAttemptsTable).where(eq(examAttemptsTable.candidateId, c.id));
    const completed = allAttempts.filter((a) => a.submittedAt != null);
    await db.update(candidatesTable).set({
      status: completed.length > 0 ? "exam_completed" : "exam_pending",
    }).where(eq(candidatesTable.id, c.id));
  }

  res.json({
    id: att.id,
    examId: att.examId,
    score,
    maxScore,
    submittedAt: submittedAt.toISOString(),
  });
});

router.get("/attempts/me", requireAuth, requireRole("student"), async (req, res) => {
  const [c] = await db.select().from(candidatesTable).where(eq(candidatesTable.userId, req.user!.userId));
  if (!c) { res.status(404).json({ error: "Candidate not found" }); return; }
  const atts = await db.select().from(examAttemptsTable).where(eq(examAttemptsTable.candidateId, c.id));
  const exams = await db.select().from(examsTable);
  res.json(atts.map((a) => {
    const e = exams.find((x) => x.id === a.examId);
    return {
      id: a.id,
      examId: a.examId,
      examTitle: e?.title ?? "",
      examKind: e?.kind ?? "",
      score: a.score,
      maxScore: a.maxScore,
      submittedAt: a.submittedAt?.toISOString() ?? null,
      startedAt: a.startedAt.toISOString(),
    };
  }));
});

export default router;
