import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, specialitiesTable } from "@workspace/db";
import { requireAuth, requireRole } from "../middleware/auth";
import { computeScoresForProgram } from "../lib/scoring";

const router: Router = Router();

router.get("/rankings", requireAuth, requireRole("super_admin", "program_admin"), async (req, res) => {
  const programId = Number(req.query["programId"]);
  if (!programId) { res.status(400).json({ error: "programId required" }); return; }
  const scores = await computeScoresForProgram(programId);
  const specs = await db.select().from(specialitiesTable).where(eq(specialitiesTable.programId, programId));
  res.json(scores.map((s, idx) => {
    const topSpecId = s.preferenceSpecIds[0];
    const topSpec = topSpecId ? specs.find((x) => x.id === topSpecId) : null;
    return {
      candidateId: s.candidateId,
      candidateCode: s.candidateCode,
      fullName: s.fullName,
      mcqScore: s.mcqScore,
      psychometricScore: s.psychometricScore,
      interviewScore: s.interviewScore,
      totalScore: s.totalScore,
      rank: idx + 1,
      topPreference: topSpec?.name ?? null,
    };
  }));
});

export default router;
