import { Router } from "express";
import { desc, eq } from "drizzle-orm";
import {
  db,
  candidatesTable,
  programsTable,
  specialitiesTable,
  examAttemptsTable,
  examsTable,
  interviewScoresTable,
  allocationsTable,
  usersTable,
} from "@workspace/db";
import { requireAuth } from "../middleware/auth";

const router: Router = Router();

router.get("/dashboard/summary", requireAuth, async (_req, res) => {
  const candidates = await db.select().from(candidatesTable);
  const programs = await db.select().from(programsTable);
  const specs = await db.select().from(specialitiesTable);
  const totalSeats = specs.reduce((s, x) => s + x.seats, 0);
  const allocs = await db.select().from(allocationsTable);
  const filledSeats = allocs.filter((a) => a.status === "SELECTED").length;
  const waitlisted = allocs.filter((a) => a.status === "WAITLISTED").length;
  const attempts = await db.select().from(examAttemptsTable);
  const attemptsCompleted = attempts.filter((a) => a.submittedAt != null).length;
  const interviews = await db.select().from(interviewScoresTable);
  const allocated = allocs.filter((a) => a.status === "SELECTED").length;

  const statusBreakdown = new Map<string, number>();
  for (const c of candidates) statusBreakdown.set(c.status, (statusBreakdown.get(c.status) ?? 0) + 1);

  res.json({
    candidates: candidates.length,
    programs: programs.length,
    specialities: specs.length,
    totalSeats,
    filledSeats,
    attemptsCompleted,
    interviewsCompleted: interviews.length,
    allocated,
    waitlisted,
    statusBreakdown: Array.from(statusBreakdown.entries()).map(([status, count]) => ({ status, count })),
  });
});

router.get("/dashboard/recent-activity", requireAuth, async (_req, res) => {
  const candidates = await db.select().from(candidatesTable).orderBy(desc(candidatesTable.createdAt)).limit(5);
  const attempts = await db.select().from(examAttemptsTable).orderBy(desc(examAttemptsTable.startedAt)).limit(5);
  const exams = await db.select().from(examsTable);
  const interviews = await db.select().from(interviewScoresTable).orderBy(desc(interviewScoresTable.submittedAt)).limit(5);
  const users = await db.select().from(usersTable);

  type Item = { id: string; kind: string; title: string; subtitle: string | null; at: string };
  const items: Item[] = [];
  for (const c of candidates) {
    items.push({
      id: `cand-${c.id}`,
      kind: "registration",
      title: `${c.fullName} registered`,
      subtitle: c.candidateCode,
      at: c.createdAt.toISOString(),
    });
  }
  for (const a of attempts) {
    const cand = candidates.find((c) => c.id === a.candidateId);
    const e = exams.find((x) => x.id === a.examId);
    const candAll = await db.select().from(candidatesTable).where(eq(candidatesTable.id, a.candidateId));
    const candFull = candAll[0];
    items.push({
      id: `att-${a.id}`,
      kind: a.submittedAt ? "exam_submitted" : "exam_started",
      title: `${candFull?.fullName ?? cand?.fullName ?? "Candidate"} ${a.submittedAt ? "submitted" : "started"} ${e?.title ?? "an exam"}`,
      subtitle: a.submittedAt ? `Score: ${a.score?.toFixed(1) ?? "—"} / ${a.maxScore?.toFixed(1) ?? "—"}` : null,
      at: (a.submittedAt ?? a.startedAt).toISOString(),
    });
  }
  for (const iv of interviews) {
    const all = await db.select().from(candidatesTable).where(eq(candidatesTable.id, iv.candidateId));
    const cand = all[0];
    const doc = users.find((u) => u.id === iv.doctorId);
    items.push({
      id: `int-${iv.id}`,
      kind: "interview_scored",
      title: `${doc?.fullName ?? "Doctor"} scored ${cand?.fullName ?? "candidate"}`,
      subtitle: `Score: ${iv.score.toFixed(1)}`,
      at: iv.submittedAt.toISOString(),
    });
  }
  items.sort((a, b) => (a.at < b.at ? 1 : -1));
  res.json(items.slice(0, 12));
});

router.get("/dashboard/exam-progress", requireAuth, async (req, res) => {
  const unitId = req.query["unitId"] ? Number(req.query["unitId"]) : undefined;
  const exams = await db.select().from(examsTable);
  const attempts = await db.select().from(examAttemptsTable);
  const candidates = await db.select().from(candidatesTable);
  const totalCandidates = unitId ? candidates.filter((c) => c.unitId === unitId).length : candidates.length;
  const candIds = unitId ? new Set(candidates.filter((c) => c.unitId === unitId).map((c) => c.id)) : null;

  res.json(exams.map((e) => {
    const examAtts = attempts.filter((a) => a.examId === e.id && (candIds == null || candIds.has(a.candidateId)));
    const completed = examAtts.filter((a) => a.submittedAt != null);
    const avg = completed.length > 0 ? completed.reduce((s, a) => s + (a.score ?? 0), 0) / completed.length : null;
    return {
      examId: e.id,
      examTitle: e.title,
      examKind: e.kind,
      totalCandidates,
      startedCount: examAtts.length,
      completedCount: completed.length,
      averageScore: avg,
    };
  }));
});

export default router;
