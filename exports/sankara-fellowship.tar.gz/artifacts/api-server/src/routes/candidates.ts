import { Router } from "express";
import { eq, desc } from "drizzle-orm";
import {
  db,
  candidatesTable,
  unitsTable,
  programsTable,
  specialitiesTable,
  candidatePreferencesTable,
  documentsTable,
  examAttemptsTable,
  examsTable,
  interviewScoresTable,
  allocationsTable,
} from "@workspace/db";
import { requireAuth, requireRole } from "../middleware/auth";

const router: Router = Router();

async function fullCandidate(c: typeof candidatesTable.$inferSelect) {
  const units = await db.select().from(unitsTable);
  const unit = c.unitId ? units.find((u) => u.id === c.unitId) : null;
  const prefs = await db.select().from(candidatePreferencesTable).where(eq(candidatePreferencesTable.candidateId, c.id));
  const specs = await db.select().from(specialitiesTable);
  const programs = await db.select().from(programsTable);
  const docs = await db.select().from(documentsTable).where(eq(documentsTable.candidateId, c.id));
  const attempts = await db.select().from(examAttemptsTable).where(eq(examAttemptsTable.candidateId, c.id));
  const exams = await db.select().from(examsTable);
  const interviews = await db.select().from(interviewScoresTable).where(eq(interviewScoresTable.candidateId, c.id));
  const alloc = await db.select().from(allocationsTable).where(eq(allocationsTable.candidateId, c.id));

  const mcqAttempts = attempts.filter((a) => {
    const e = exams.find((x) => x.id === a.examId);
    return e?.kind === "mcq";
  });
  const psychoAttempts = attempts.filter((a) => {
    const e = exams.find((x) => x.id === a.examId);
    return e?.kind?.startsWith("psychometric");
  });
  const mcqScore = mcqAttempts.length > 0
    ? mcqAttempts.reduce((s, a) => s + (a.score ?? 0), 0) / mcqAttempts.length
    : null;
  const psychometricScore = psychoAttempts.length > 0
    ? psychoAttempts.reduce((s, a) => s + (a.score ?? 0), 0) / psychoAttempts.length
    : null;
  const interviewScore = interviews.length > 0
    ? interviews.reduce((s, i) => s + i.score, 0) / interviews.length
    : null;

  const totalScore = (mcqScore != null || psychometricScore != null || interviewScore != null)
    ? (mcqScore ?? 0) + (psychometricScore ?? 0) + (interviewScore ?? 0)
    : null;

  return {
    id: c.id,
    candidateCode: c.candidateCode,
    fullName: c.fullName,
    email: c.email,
    phone: c.phone,
    unitId: c.unitId,
    unitName: unit?.name ?? null,
    status: c.status,
    mcqScore,
    psychometricScore,
    interviewScore,
    totalScore,
    rank: alloc[0]?.rank ?? null,
    createdAt: c.createdAt.toISOString(),
    dateOfBirth: c.dateOfBirth,
    gender: c.gender,
    qualification: c.qualification,
    collegeName: c.collegeName,
    address: c.address,
    preferences: prefs.sort((a, b) => a.preferenceOrder - b.preferenceOrder).map((p) => {
      const sp = specs.find((s) => s.id === p.specialityId);
      const pg = sp ? programs.find((g) => g.id === sp.programId) : null;
      return {
        id: p.id,
        specialityId: p.specialityId,
        specialityName: sp?.name ?? "",
        programName: pg?.name ?? "",
        preferenceOrder: p.preferenceOrder,
      };
    }),
    documents: docs.map((d) => ({
      id: d.id,
      docType: d.docType,
      fileName: d.fileName,
      uploadedAt: d.uploadedAt.toISOString(),
    })),
    attempts: attempts.map((a) => {
      const e = exams.find((x) => x.id === a.examId);
      return {
        id: a.id,
        examId: a.examId,
        examTitle: e?.title ?? "",
        examKind: e?.kind ?? "",
        score: a.score,
        maxScore: a.maxScore,
        submittedAt: a.submittedAt?.toISOString() ?? null,
        startedAt: a.startedAt.toISOString(),
      };
    }),
  };
}

router.get("/candidates", requireAuth, requireRole("super_admin", "program_admin", "exam_coordinator", "doctor"), async (req, res) => {
  const programId = req.query["programId"] ? Number(req.query["programId"]) : undefined;
  const unitIdRaw = req.query["unitId"] ? Number(req.query["unitId"]) : undefined;
  const status = req.query["status"] as string | undefined;

  // Coordinator: force their unit
  let effectiveUnit = unitIdRaw;
  if (req.user!.role === "exam_coordinator") {
    const { usersTable } = await import("@workspace/db");
    const [u] = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.userId));
    effectiveUnit = u?.unitId ?? -1;
  }

  let candidates = await db.select().from(candidatesTable).orderBy(desc(candidatesTable.createdAt));
  if (effectiveUnit !== undefined) candidates = candidates.filter((c) => c.unitId === effectiveUnit);
  if (status) candidates = candidates.filter((c) => c.status === status);

  if (programId) {
    const prefs = await db.select().from(candidatePreferencesTable);
    const specs = await db.select().from(specialitiesTable).where(eq(specialitiesTable.programId, programId));
    const specIds = new Set(specs.map((s) => s.id));
    const candidateIds = new Set(prefs.filter((p) => specIds.has(p.specialityId)).map((p) => p.candidateId));
    candidates = candidates.filter((c) => candidateIds.has(c.id));
  }

  const units = await db.select().from(unitsTable);
  const out = candidates.map((c) => {
    const unit = c.unitId ? units.find((u) => u.id === c.unitId) : null;
    return {
      id: c.id,
      candidateCode: c.candidateCode,
      fullName: c.fullName,
      email: c.email,
      phone: c.phone,
      unitId: c.unitId,
      unitName: unit?.name ?? null,
      status: c.status,
      mcqScore: null,
      psychometricScore: null,
      interviewScore: null,
      totalScore: null,
      rank: null,
      createdAt: c.createdAt.toISOString(),
    };
  });
  res.json(out);
});

router.get("/candidates/me", requireAuth, requireRole("student"), async (req, res) => {
  const [c] = await db.select().from(candidatesTable).where(eq(candidatesTable.userId, req.user!.userId));
  if (!c) { res.status(404).json({ error: "Candidate not found" }); return; }
  res.json(await fullCandidate(c));
});

router.patch("/candidates/me", requireAuth, requireRole("student"), async (req, res) => {
  const [c] = await db.select().from(candidatesTable).where(eq(candidatesTable.userId, req.user!.userId));
  if (!c) { res.status(404).json({ error: "Candidate not found" }); return; }
  const body = req.body as Record<string, string | undefined>;
  const update: Record<string, unknown> = {};
  for (const k of ["fullName", "phone", "dateOfBirth", "gender", "qualification", "collegeName", "address"]) {
    if (body[k] !== undefined) update[k] = body[k];
  }
  const [updated] = await db.update(candidatesTable).set(update).where(eq(candidatesTable.id, c.id)).returning();
  if (!updated) { res.status(500).json({ error: "Failed" }); return; }
  res.json(await fullCandidate(updated));
});

router.get("/candidates/:candidateId", requireAuth, async (req, res) => {
  const id = Number(req.params["candidateId"]);
  const [c] = await db.select().from(candidatesTable).where(eq(candidatesTable.id, id));
  if (!c) { res.status(404).json({ error: "Not found" }); return; }
  res.json(await fullCandidate(c));
});

router.post("/candidates/:candidateId/assign-unit", requireAuth, requireRole("super_admin", "program_admin"), async (req, res) => {
  const id = Number(req.params["candidateId"]);
  const { unitId } = req.body as { unitId: number };
  const [c] = await db.update(candidatesTable).set({ unitId }).where(eq(candidatesTable.id, id)).returning();
  if (!c) { res.status(404).json({ error: "Not found" }); return; }
  const units = await db.select().from(unitsTable);
  const unit = c.unitId ? units.find((u) => u.id === c.unitId) : null;
  res.json({
    id: c.id,
    candidateCode: c.candidateCode,
    fullName: c.fullName,
    email: c.email,
    phone: c.phone,
    unitId: c.unitId,
    unitName: unit?.name ?? null,
    status: c.status,
    mcqScore: null,
    psychometricScore: null,
    interviewScore: null,
    totalScore: null,
    rank: null,
    createdAt: c.createdAt.toISOString(),
  });
});

export default router;
