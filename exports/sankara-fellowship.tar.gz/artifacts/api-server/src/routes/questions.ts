import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, examsTable, questionsTable, optionsTable } from "@workspace/db";
import { requireAuth, requireRole } from "../middleware/auth";

const router: Router = Router();

async function questionWithOptions(q: typeof questionsTable.$inferSelect) {
  const opts = await db.select().from(optionsTable).where(eq(optionsTable.questionId, q.id));
  return {
    id: q.id,
    examId: q.examId,
    kind: q.kind,
    body: q.body,
    marks: q.marks,
    pairId: q.pairId,
    rule: q.rule,
    options: opts.sort((a, b) => a.position - b.position).map((o) => ({
      id: o.id,
      body: o.body,
      isCorrect: o.isCorrect,
      score: o.score,
    })),
  };
}

router.get("/exams/:examId/questions", requireAuth, requireRole("super_admin", "program_admin"), async (req, res) => {
  const examId = Number(req.params["examId"]);
  const qs = await db.select().from(questionsTable).where(eq(questionsTable.examId, examId));
  const out = await Promise.all(qs.map(questionWithOptions));
  res.json(out);
});

router.post("/exams/:examId/questions", requireAuth, requireRole("super_admin", "program_admin"), async (req, res) => {
  const examId = Number(req.params["examId"]);
  const [exam] = await db.select().from(examsTable).where(eq(examsTable.id, examId));
  if (!exam) { res.status(404).json({ error: "Exam not found" }); return; }
  const body = req.body as {
    kind: string;
    body: string;
    marks: number;
    pairId?: number | null;
    rule?: unknown;
    options: Array<{ body: string; isCorrect?: boolean; score?: number }>;
  };
  const [q] = await db.insert(questionsTable).values({
    examId,
    kind: body.kind,
    body: body.body,
    marks: body.marks,
    pairId: body.pairId ?? null,
    rule: body.rule ?? null,
  }).returning();
  if (!q) { res.status(500).json({ error: "Failed" }); return; }
  if (body.options && body.options.length > 0) {
    await db.insert(optionsTable).values(body.options.map((o, idx) => ({
      questionId: q.id,
      body: o.body,
      isCorrect: o.isCorrect ?? false,
      score: o.score ?? null,
      position: idx,
    })));
  }
  res.json(await questionWithOptions(q));
});

router.post("/exams/:examId/questions/bulk", requireAuth, requireRole("super_admin", "program_admin"), async (req, res) => {
  const examId = Number(req.params["examId"]);
  const [exam] = await db.select().from(examsTable).where(eq(examsTable.id, examId));
  if (!exam) { res.status(404).json({ error: "Exam not found" }); return; }
  const { rows } = req.body as {
    rows: Array<{ body: string; optionA: string; optionB: string; optionC: string; optionD: string; correct: string; marks?: number }>;
  };
  if (!Array.isArray(rows) || rows.length === 0) { res.status(400).json({ error: "rows required" }); return; }
  let inserted = 0;
  for (const row of rows) {
    if (!row.body || !row.optionA || !row.optionB || !row.optionC || !row.optionD || !row.correct) continue;
    const [q] = await db.insert(questionsTable).values({
      examId,
      kind: "mcq",
      body: row.body,
      marks: row.marks ?? 1,
    }).returning();
    if (!q) continue;
    const correctLetter = row.correct.trim().toUpperCase();
    const opts = [
      { body: row.optionA, isCorrect: correctLetter === "A" },
      { body: row.optionB, isCorrect: correctLetter === "B" },
      { body: row.optionC, isCorrect: correctLetter === "C" },
      { body: row.optionD, isCorrect: correctLetter === "D" },
    ];
    await db.insert(optionsTable).values(opts.map((o, i) => ({
      questionId: q.id,
      body: o.body,
      isCorrect: o.isCorrect,
      score: null,
      position: i,
    })));
    inserted++;
  }
  res.json({ inserted });
});

export default router;
