import {
  db,
  usersTable,
  unitsTable,
  programsTable,
  specialitiesTable,
  candidatesTable,
  candidatePreferencesTable,
  examsTable,
  questionsTable,
  optionsTable,
  doctorAssignmentsTable,
} from "@workspace/db";
import bcrypt from "bcryptjs";

async function main() {
  console.log("Seeding database…");

  // wipe (in dependency order)
  await db.delete(doctorAssignmentsTable);
  await db.delete(candidatePreferencesTable);
  await db.delete(optionsTable);
  await db.delete(questionsTable);
  await db.delete(examsTable);
  await db.delete(candidatesTable);
  await db.delete(specialitiesTable);
  await db.delete(programsTable);
  await db.delete(unitsTable);
  await db.delete(usersTable);

  const hash = (p: string) => bcrypt.hash(p, 10);

  // Units
  const units = await db.insert(unitsTable).values([
    { name: "Sankara Eye Hospital - Bangalore", city: "Bangalore", state: "Karnataka" },
    { name: "Sankara Eye Hospital - Shimoga", city: "Shimoga", state: "Karnataka" },
    { name: "Sankara Eye Hospital - Coimbatore", city: "Coimbatore", state: "Tamil Nadu" },
    { name: "Sankara Eye Hospital - Hyderabad", city: "Hyderabad", state: "Telangana" },
    { name: "Sankara Eye Hospital - Anand", city: "Anand", state: "Gujarat" },
  ]).returning();

  // Users
  const sa = await hash("admin@123");
  const pa = await hash("program@123");
  const ec = await hash("coord@123");
  const dr = await hash("doctor@123");
  const st = await hash("student@123");

  const [superAdmin] = await db.insert(usersTable).values([
    { email: "superadmin@sankara.org", passwordHash: sa, fullName: "Dr. Ramesh Kumar", role: "super_admin" },
  ]).returning();

  const [programAdmin] = await db.insert(usersTable).values([
    { email: "programadmin@sankara.org", passwordHash: pa, fullName: "Dr. Anita Sharma", role: "program_admin" },
  ]).returning();

  const coordinators = await db.insert(usersTable).values([
    { email: "coord.bangalore@sankara.org", passwordHash: ec, fullName: "Suresh Iyer", role: "exam_coordinator", unitId: units[0]!.id },
    { email: "coord.shimoga@sankara.org", passwordHash: ec, fullName: "Lakshmi Rao", role: "exam_coordinator", unitId: units[1]!.id },
  ]).returning();

  const doctors = await db.insert(usersTable).values([
    { email: "dr.priya@sankara.org", passwordHash: dr, fullName: "Dr. Priya Nair", role: "doctor", unitId: units[0]!.id },
    { email: "dr.vinod@sankara.org", passwordHash: dr, fullName: "Dr. Vinod Menon", role: "doctor", unitId: units[0]!.id },
    { email: "dr.kavita@sankara.org", passwordHash: dr, fullName: "Dr. Kavita Reddy", role: "doctor", unitId: units[2]!.id },
  ]).returning();

  // Programs + specialities
  const [progRetina, progCornea] = await db.insert(programsTable).values([
    { name: "Long-term Fellowship in Vitreo-Retinal Surgery", code: "VR-2026", academicYear: "2026-27", description: "Two-year vitreo-retinal surgical fellowship across Sankara units." },
    { name: "Long-term Fellowship in Cornea & Refractive Surgery", code: "CR-2026", academicYear: "2026-27", description: "Two-year fellowship in cornea, refractive surgery, and ocular surface diseases." },
  ]).returning();

  const retSpecs = await db.insert(specialitiesTable).values([
    { programId: progRetina!.id, name: "Vitreo-Retina", code: "VR", seats: 4 },
    { programId: progRetina!.id, name: "Medical Retina", code: "MR", seats: 3 },
    { programId: progRetina!.id, name: "Pediatric Retina", code: "PR", seats: 2 },
  ]).returning();

  const corSpecs = await db.insert(specialitiesTable).values([
    { programId: progCornea!.id, name: "Cornea & Anterior Segment", code: "CAS", seats: 4 },
    { programId: progCornea!.id, name: "Refractive Surgery", code: "RS", seats: 3 },
    { programId: progCornea!.id, name: "Ocular Surface", code: "OS", seats: 2 },
  ]).returning();

  // Students
  const studentNames = [
    "Aarav Mehta", "Diya Krishnan", "Ishaan Patel", "Kavya Iyer", "Rohan Gupta",
    "Sneha Reddy", "Vikram Singh", "Aisha Khan", "Aditya Verma", "Tanvi Joshi",
    "Karthik Kumar", "Nisha Pillai", "Arjun Das", "Meera Bhat", "Siddharth Roy",
  ];
  const candidates: Array<{ id: number; userId: number; fullName: string }> = [];
  let codeCounter = 1;
  const year = new Date().getFullYear();
  for (let i = 0; i < studentNames.length; i++) {
    const name = studentNames[i]!;
    const email = name.toLowerCase().replace(/[^a-z]+/g, ".") + "@example.com";
    const [u] = await db.insert(usersTable).values({
      email,
      passwordHash: st,
      fullName: name,
      role: "student",
    }).returning();
    if (!u) continue;
    const code = `SEH-${year}-${String(codeCounter++).padStart(4, "0")}`;
    const unitId = units[i % units.length]!.id;
    const [c] = await db.insert(candidatesTable).values({
      userId: u.id,
      candidateCode: code,
      fullName: name,
      email,
      phone: `+91 9${String(800000000 + i * 12345).slice(0, 9)}`,
      dateOfBirth: `199${5 + (i % 5)}-0${(i % 9) + 1}-15`,
      gender: i % 2 === 0 ? "Male" : "Female",
      qualification: "MBBS, MS Ophthalmology",
      collegeName: ["AIIMS Delhi", "Madras Medical College", "JIPMER", "KMC Manipal", "MGM Mumbai"][i % 5]!,
      address: `${100 + i} ${["MG Road", "Nehru Street", "Gandhi Marg", "Park Avenue", "Lake View"][i % 5]}, India`,
      unitId,
      status: "registered",
    }).returning();
    if (c) candidates.push({ id: c.id, userId: u.id, fullName: name });
  }

  // Preferences: each candidate picks 3 specs from each program-relevant set
  const allSpecs = [...retSpecs, ...corSpecs];
  for (const c of candidates) {
    const shuffled = [...allSpecs].sort(() => Math.random() - 0.5).slice(0, 4);
    await db.insert(candidatePreferencesTable).values(shuffled.map((s, idx) => ({
      candidateId: c.id,
      specialityId: s.id,
      preferenceOrder: idx + 1,
    })));
  }

  // Exam: MCQ for retina program
  const [mcqExam] = await db.insert(examsTable).values({
    title: "Vitreo-Retina Entrance MCQ",
    kind: "mcq",
    programId: progRetina!.id,
    durationMinutes: 60,
    totalQuestions: 10,
    passingScore: 6,
    description: "Multiple choice questions on retinal anatomy, pathology, and surgical procedures.",
  }).returning();

  const mcqQuestions = [
    {
      body: "Which layer of the retina contains the photoreceptors?",
      opts: ["Inner nuclear layer", "Outer nuclear layer", "Ganglion cell layer", "Inner plexiform layer"],
      correct: 1,
    },
    {
      body: "What is the most common cause of central retinal artery occlusion?",
      opts: ["Embolism", "Vasculitis", "Hypertension", "Diabetes"],
      correct: 0,
    },
    {
      body: "Which of the following is the gold standard imaging for diabetic macular edema?",
      opts: ["Fluorescein angiography", "OCT", "B-scan ultrasound", "Indocyanine green angiography"],
      correct: 1,
    },
    {
      body: "Anti-VEGF therapy primarily targets which condition?",
      opts: ["Cataract", "Glaucoma", "Wet AMD", "Refractive errors"],
      correct: 2,
    },
    {
      body: "The macula is located approximately how many mm from the optic disc?",
      opts: ["1-2 mm", "3-4 mm", "5-7 mm", "8-10 mm"],
      correct: 1,
    },
    {
      body: "Retinitis pigmentosa is characterized by which initial symptom?",
      opts: ["Central vision loss", "Night blindness", "Color blindness", "Diplopia"],
      correct: 1,
    },
    {
      body: "Pars plana vitrectomy is performed through which structure?",
      opts: ["Cornea", "Sclera", "Iris", "Conjunctiva"],
      correct: 1,
    },
    {
      body: "Which gauge instrumentation is most commonly used in modern vitrectomy?",
      opts: ["20G", "23G", "25G", "30G"],
      correct: 2,
    },
    {
      body: "Macular hole closure rates with vitrectomy + ILM peeling are approximately:",
      opts: ["40-50%", "60-70%", "80-90%", "Over 95%"],
      correct: 2,
    },
    {
      body: "Which dye is commonly used to stain the internal limiting membrane?",
      opts: ["Trypan blue", "Brilliant blue G", "Indocyanine green", "All of the above"],
      correct: 3,
    },
  ];
  for (const q of mcqQuestions) {
    const [ins] = await db.insert(questionsTable).values({
      examId: mcqExam!.id,
      kind: "mcq",
      body: q.body,
      marks: 1,
    }).returning();
    if (!ins) continue;
    await db.insert(optionsTable).values(q.opts.map((o, idx) => ({
      questionId: ins.id,
      body: o,
      isCorrect: idx === q.correct,
      score: null,
      position: idx,
    })));
  }

  // Psychometric exam
  const [psyExam] = await db.insert(examsTable).values({
    title: "Psychometric Assessment",
    kind: "psychometric_scale",
    programId: progRetina!.id,
    durationMinutes: 30,
    totalQuestions: 8,
    description: "Likert-scale assessment of stress tolerance, communication, and ethical reasoning.",
  }).returning();

  const psyQuestions = [
    "I remain calm under pressure during long surgical procedures.",
    "I consistently communicate findings clearly to patients and families.",
    "I prioritize patient outcomes above personal recognition.",
    "I welcome constructive criticism from senior colleagues.",
    "I adapt readily to changes in surgical plans.",
    "I take responsibility for my mistakes without excuses.",
    "I am energized by complex diagnostic challenges.",
    "I respect colleagues from all clinical backgrounds.",
  ];
  for (const body of psyQuestions) {
    const [ins] = await db.insert(questionsTable).values({
      examId: psyExam!.id,
      kind: "psychometric_scale",
      body,
      marks: 5,
      rule: { min: 1, max: 5, labels: ["Strongly disagree", "Disagree", "Neutral", "Agree", "Strongly agree"] },
    }).returning();
    if (!ins) continue;
    await db.insert(optionsTable).values([1, 2, 3, 4, 5].map((n) => ({
      questionId: ins.id,
      body: String(n),
      isCorrect: false,
      score: n,
      position: n - 1,
    })));
  }

  // Doctor assignments — assign first doctor to first 8 candidates, second doctor to next 7
  for (let i = 0; i < candidates.length; i++) {
    const c = candidates[i]!;
    const doctor = doctors[i % doctors.length]!;
    await db.insert(doctorAssignmentsTable).values({
      doctorId: doctor.id,
      candidateId: c.id,
      status: "pending",
    });
  }

  console.log("Seed complete");
  console.log("");
  console.log("Login credentials:");
  console.log("  Super Admin:        superadmin@sankara.org / admin@123");
  console.log("  Program Admin:      programadmin@sankara.org / program@123");
  console.log("  Exam Coordinator:   coord.bangalore@sankara.org / coord@123");
  console.log("  Doctor:             dr.priya@sankara.org / doctor@123");
  console.log("  Student:            aarav.mehta@example.com / student@123");
  console.log("");
  console.log(`Seeded: ${units.length} units, 2 programs, ${retSpecs.length + corSpecs.length} specialities, ${candidates.length} candidates, 2 exams.`);

  // Suppress unused-var warnings
  void superAdmin; void programAdmin; void coordinators;

  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
